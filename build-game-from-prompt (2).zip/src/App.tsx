import { useState } from "react";
import type { User } from "./lib/types";
import { getRoomFromUrl, isOnline, loadMembers, loadUser, saveUser } from "./lib/store";
import JoinScreen from "./components/JoinScreen";
import ChatRoom from "./components/ChatRoom";

const CAP = 20;

export default function App() {
  const [user, setUser] = useState<User | null>(() => loadUser());
  const [room, setRoom] = useState(() => getRoomFromUrl());
  const [joined, setJoined] = useState(false);
  const [full, setFull] = useState(false);

  const handleJoin = (u: User, r: string) => {
    // enforce the 20-member cap (online humans + arena regulars)
    const members = loadMembers(r);
    const onlineOthers = members.filter((m) => m.id !== u.id && (m.bot || isOnline(m)));
    const alreadyIn = members.some((m) => m.id === u.id);
    if (!alreadyIn && onlineOthers.length >= CAP) {
      setFull(true);
      setRoom(r);
      return;
    }
    saveUser(u);
    setUser(u);
    setRoom(r);
    setFull(false);
    const url = new URL(window.location.href);
    url.search = "?room=" + r;
    window.history.replaceState({}, "", url.toString());
    setJoined(true);
  };

  if (!joined || !user) {
    return <JoinScreen initialRoom={room} onJoin={handleJoin} full={full} />;
  }
  return <ChatRoom me={user} room={room} onLeave={() => setJoined(false)} />;
}