export interface User {
  id: string;
  name: string;
  avatar: string; // data URL
}

export interface Member extends User {
  lastSeen: number;
  bot?: boolean;
  admin?: boolean;
}

export type AttachmentType = "image" | "file" | "audio" | "gif";

export interface Attachment {
  type: AttachmentType;
  name: string;
  url: string;
  mime: string;
  size?: number;
  ephemeral?: boolean; // too large to persist
}

/* ---------- search cards & expressive rich objects ---------- */
export type Vertical =
  | "fact"
  | "trains"
  | "flights"
  | "movies"
  | "trips"
  | "stays"
  | "weather"
  | "places"
  | "food"
  | "shopping"
  | "money";

export interface ResultLink {
  label: string;
  url: string;
  icon: string;
  note?: string;
}

export interface ResultRow {
  title: string;
  subtitle?: string;
  meta?: string;
  url?: string;
  tag?: string;
}

export interface PollOption {
  id: string;
  label: string;
  votes: string[]; // array of user names
}

export interface ItineraryDay {
  day: string;
  activity: string;
  estCost?: string;
  icon?: string;
}

export interface SearchCard {
  vertical: Vertical;
  label: string;
  icon: string;
  query: string;
  headline: string;
  detail?: string;
  rows?: ResultRow[];
  links: ResultLink[];
  source?: { title: string; url: string };
  tips?: string[];
  note?: string; // the sharer's own note
  askVote?: boolean; // invite teammates to react/vote
  poll?: PollOption[]; // live team poll on the card
  itinerary?: ItineraryDay[]; // trip timeline builder
  splitEstimate?: { total: string; perPerson: string; count: number };
}

export type MsgKind = "chat" | "system" | "ai";

export interface Message {
  id: string;
  kind: MsgKind;
  userId: string;
  name: string;
  avatar: string;
  ts: number;
  text?: string;
  attachment?: Attachment;
  card?: SearchCard;
  reactions?: Record<string, string[]>; // emoji -> names
}

/* ---------- expanded collaborative games ---------- */
export type GameId =
  | "bomb"
  | "astro"
  | "reactor"
  | "cipher"
  | "chain"
  | "blitz"
  | "codebreak"
  | "story"
  | "tictactoe"
  | "connect4"
  | "slide"
  | "wikirace"
  | "controller"
  | "npc"
  | "desk";

export interface GamePlayer {
  uid: string;
  name: string;
  avatar: string;
  score: number;
  bot?: boolean;
  role?: string;
}

export interface FeedLine {
  name: string;
  text: string;
  ts: number;
  sys?: boolean;
}

export interface LiveGame {
  id: GameId;
  v: number;
  seed: number;
  startedBy: string;
  startedAt: number;
  endsAt: number;
  phase: "play" | "done";
  players: GamePlayer[];
  turn: number;
  feed: FeedLine[];
  data: any;
  result?: string;
  bonus?: string;
}

export const GAME_META: Record<
  GameId,
  { name: string; emoji: string; blurb: string; minutes: string; tag: string }
> = {
  bomb: {
    name: "Defuse the Bomb",
    emoji: "🧨",
    blurb: "Asymmetric clues: each player receives a secret clue to find the safe wire",
    minutes: "75s",
    tag: "Deduction",
  },
  astro: {
    name: "Starship Emergency Repair",
    emoji: "🚀",
    blurb: "Critical system failure: team coordinates 4 ship consoles before countdown",
    minutes: "80s",
    tag: "Co-op Sim",
  },
  reactor: {
    name: "Quantum Reactor Sync",
    emoji: "⚡",
    blurb: "Team synchronizes pulsating power grids in alternating frequency cycles",
    minutes: "60s",
    tag: "Rhythm & Sync",
  },
  cipher: {
    name: "Emoji Cipher Hack",
    emoji: "🕵️",
    blurb: "Crack the secret transmission — each player holds decryption keys for specific runes",
    minutes: "90s",
    tag: "Puzzle Hack",
  },
  chain: {
    name: "Word Chain Relay",
    emoji: "🔗",
    blurb: "Pass the baton around the squad — each word links to the next letter",
    minutes: "90s",
    tag: "Word Relay",
  },
  blitz: {
    name: "Target Blitz Co-op",
    emoji: "🎯",
    blurb: "One massive shared target meter — all players tap simultaneously",
    minutes: "35s",
    tag: "Speed Co-op",
  },
  codebreak: {
    name: "Code Breakers",
    emoji: "🧩",
    blurb: "Cooperative Mastermind — team collaborates to deduct the 4-symbol sequence",
    minutes: "90s",
    tag: "Strategy",
  },
  story: {
    name: "Story Relay",
    emoji: "📖",
    blurb: "Write a ridiculous story together, 2–8 words per player turn",
    minutes: "100s",
    tag: "Creative",
  },
  tictactoe: {
    name: "Tic-Tac-Toe Teams",
    emoji: "⭕",
    blurb: "Instant shared-screen classic — alternating teammates play for X and O",
    minutes: "75s",
    tag: "Instant Classic",
  },
  connect4: {
    name: "Connect Four Teams",
    emoji: "🔴",
    blurb: "Drop discs on one shared board and connect four before the other side",
    minutes: "100s",
    tag: "Instant Classic",
  },
  slide: {
    name: "Sliding Puzzle Relay",
    emoji: "🧩",
    blurb: "One solvable grid, one move per teammate — restore the picture of numbers",
    minutes: "120s",
    tag: "Grid Puzzle",
  },
  wikirace: {
    name: "WikiRace Live",
    emoji: "🏁",
    blurb: "Race through real Wikipedia internal links from the start page to the target",
    minutes: "180s",
    tag: "Web Race",
  },
  controller: {
    name: "Pass the Controller",
    emoji: "🎮",
    blurb: "Record your move, smash PASS, and cut the camera to the next teammate",
    minutes: "150s",
    tag: "Video Relay",
  },
  npc: {
    name: "The NPC Walk",
    emoji: "🚶",
    blurb: "30-second camera challenge — move like a gloriously glitchy background NPC",
    minutes: "150s",
    tag: "Video Icebreaker",
  },
  desk: {
    name: "Speedrun Your Desk",
    emoji: "🗄️",
    blurb: "Organize your desk in a 15-second recording with an original arcade soundtrack",
    minutes: "150s",
    tag: "Video Speedrun",
  },
};

export type BusEvent =
  | { t: "msg"; m: Message }
  | { t: "update"; m: Message }
  | { t: "del"; id: string }
  | { t: "typing"; uid: string; name: string; until: number }
  | { t: "game"; g: LiveGame | null }
  | { t: "presence" };

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);