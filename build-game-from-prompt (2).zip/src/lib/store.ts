import type { Member, Message, User } from "./types";

const P = "chatarena_";

export const RETENTION_OPTIONS = [2, 7, 30] as const;

export function getRetentionDays(): number {
  const v = Number(localStorage.getItem(P + "retention"));
  return RETENTION_OPTIONS.includes(v as (typeof RETENTION_OPTIONS)[number]) ? v : 2;
}
export function setRetentionDays(d: number) {
  localStorage.setItem(P + "retention", String(d));
}

export function getProfanityFilter(): boolean {
  return localStorage.getItem(P + "profanity") !== "off";
}
export function setProfanityFilter(on: boolean) {
  localStorage.setItem(P + "profanity", on ? "on" : "off");
}

const BAD_WORDS = ["damn", "hell", "crap", "ass", "bastard", "shit", "fuck", "bitch"];
export function cleanText(text: string): string {
  if (!getProfanityFilter()) return text;
  return text.replace(/\b\w+\b/g, (w) =>
    BAD_WORDS.includes(w.toLowerCase()) ? w[0] + "•".repeat(Math.max(1, w.length - 1)) : w
  );
}

// ---------- user ----------
export function loadUser(): User | null {
  try {
    const raw = localStorage.getItem(P + "user");
    return raw ? (JSON.parse(raw) as User) : null;
  } catch {
    return null;
  }
}
export function saveUser(u: User) {
  localStorage.setItem(P + "user", JSON.stringify(u));
}

// ---------- messages ----------
export function loadMessages(room: string): Message[] {
  try {
    const raw = localStorage.getItem(P + "msgs_" + room);
    if (!raw) return [];
    const cutoff = Date.now() - getRetentionDays() * 86400000;
    return (JSON.parse(raw) as Message[]).filter((m) => m.ts >= cutoff);
  } catch {
    return [];
  }
}

export function saveMessages(room: string, msgs: Message[]) {
  const cutoff = Date.now() - getRetentionDays() * 86400000;
  let keep = msgs.filter((m) => m.ts >= cutoff).slice(-400);
  const attempt = (list: Message[]) => localStorage.setItem(P + "msgs_" + room, JSON.stringify(list));
  try {
    attempt(keep);
  } catch {
    // Quota exceeded: drop attachments from oldest messages first
    keep = keep.map((m, i) =>
      m.attachment?.url.startsWith("data:") && i < keep.length - 20
        ? { ...m, attachment: { ...m.attachment, url: "", ephemeral: true } }
        : m
    );
    try {
      attempt(keep);
    } catch {
      attempt(keep.slice(-100).map((m) => (m.attachment ? { ...m, attachment: { ...m.attachment, url: m.attachment.url.startsWith("data:") ? "" : m.attachment.url, ephemeral: true } } : m)));
    }
  }
}

// ---------- members ----------
export function loadMembers(room: string): Member[] {
  try {
    return JSON.parse(localStorage.getItem(P + "members_" + room) || "[]") as Member[];
  } catch {
    return [];
  }
}
export function saveMembers(room: string, members: Member[]) {
  try {
    localStorage.setItem(P + "members_" + room, JSON.stringify(members.slice(0, 40)));
  } catch {
    /* ignore */
  }
}
export const ONLINE_WINDOW = 16000;
export const isOnline = (m: Member) => !!m.bot || Date.now() - m.lastSeen < ONLINE_WINDOW;

// ---------- leader election (only one tab drives the bots) ----------
const TAB_ID = Math.random().toString(36).slice(2);
export function claimLeadership(room: string): boolean {
  const key = P + "leader_" + room;
  try {
    const cur = JSON.parse(localStorage.getItem(key) || "null") as { id: string; ts: number } | null;
    if (!cur || cur.id === TAB_ID || Date.now() - cur.ts > 12000) {
      localStorage.setItem(key, JSON.stringify({ id: TAB_ID, ts: Date.now() }));
      return true;
    }
    return false;
  } catch {
    return true;
  }
}

export function getRoomFromUrl(): string {
  const q = new URLSearchParams(window.location.search).get("room");
  return (q || "lobby").toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 24) || "lobby";
}

export function roomLink(room: string): string {
  const u = new URL(window.location.href);
  u.search = "?room=" + room;
  u.hash = "";
  return u.toString();
}