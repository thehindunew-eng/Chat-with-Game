import { useRef, useState } from "react";
import type { User } from "../lib/types";
import { uid } from "../lib/types";
import { makeAvatar } from "../lib/data";

interface Props {
  initialRoom: string;
  onJoin: (user: User, room: string) => void;
  full?: boolean;
}

function resizeImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const size = 96;
      const canvas = document.createElement("canvas");
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d")!;
      const min = Math.min(img.width, img.height);
      ctx.drawImage(img, (img.width - min) / 2, (img.height - min) / 2, min, min, 0, 0, size, size);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = reject;
    img.src = url;
  });
}

export default function JoinScreen({ initialRoom, onJoin, full }: Props) {
  const [name, setName] = useState("");
  const [room, setRoom] = useState(initialRoom);
  const [avatar, setAvatar] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const pickFile = async (f: File | undefined) => {
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      setErr("Please choose an image file for your picture.");
      return;
    }
    try {
      setAvatar(await resizeImage(f));
      setErr("");
    } catch {
      setErr("Couldn't read that image — try another one.");
    }
  };

  const submit = () => {
    const n = name.trim();
    if (!n) return setErr("Enter a display name — anything goes!");
    if (!avatar) return setErr("Upload a profile picture (or tap the dice for a random one).");
    const r = room.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 24) || "lobby";
    onJoin({ id: uid(), name: n.slice(0, 24), avatar }, r);
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-950 p-4">
      {/* ambient background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-violet-600/25 blur-3xl" />
        <div className="absolute -right-32 top-1/3 h-96 w-96 rounded-full bg-fuchsia-600/20 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-80 w-80 rounded-full bg-indigo-600/20 blur-3xl" />
        <div className="absolute left-[12%] top-[18%] animate-bounce text-3xl opacity-40" style={{ animationDuration: "3s" }}>🎮</div>
        <div className="absolute right-[15%] top-[12%] animate-bounce text-2xl opacity-40" style={{ animationDuration: "4s" }}>💬</div>
        <div className="absolute bottom-[15%] right-[22%] animate-bounce text-3xl opacity-40" style={{ animationDuration: "3.5s" }}>🎯</div>
      </div>

      <div className="relative w-full max-w-md">
        <div className="mb-6 text-center">
          <div className="mb-3 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-3xl shadow-lg shadow-violet-900/50">
            ⚡
          </div>
          <h1 className="text-4xl font-black tracking-tight text-white">
            Chat<span className="bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">Arena</span>
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            Chat, plan and search together. Type <span className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-amber-300">GAME</span> and the whole room plays a team game. 🎮
          </p>
        </div>

        {full && (
          <div className="mb-4 rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-200">
            🚫 <b>Room “{initialRoom}” is full</b> (20/20 members). Pick a different room name below to create or join another one.
          </div>
        )}

        <div className="rounded-2xl border border-white/10 bg-white/5 p-6 shadow-2xl backdrop-blur-xl">
          {/* avatar */}
          <div className="mb-5 flex items-center gap-4">
            <button
              onClick={() => fileRef.current?.click()}
              className="group relative h-20 w-20 shrink-0 overflow-hidden rounded-full border-2 border-dashed border-slate-600 bg-slate-800/60 transition hover:border-violet-400"
              title="Upload your picture"
            >
              {avatar ? (
                <img src={avatar} alt="avatar" className="h-full w-full object-cover" />
              ) : (
                <span className="flex h-full w-full flex-col items-center justify-center text-slate-400 group-hover:text-violet-300">
                  <span className="text-xl">📷</span>
                  <span className="text-[9px] font-semibold">UPLOAD</span>
                </span>
              )}
            </button>
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">Your picture</p>
              <p className="text-xs text-slate-400">Any image works — it becomes your avatar.</p>
              <button
                onClick={() => { setAvatar(makeAvatar(name || "?", Math.floor(Math.random() * 360))); setErr(""); }}
                className="mt-1.5 rounded-lg bg-slate-800 px-2.5 py-1 text-xs font-medium text-violet-300 transition hover:bg-slate-700"
              >
                🎲 Surprise me instead
              </button>
            </div>
            <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => pickFile(e.target.files?.[0])} />
          </div>

          <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">Display name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            maxLength={24}
            placeholder="e.g. CaptainChai"
            className="mb-4 w-full rounded-xl border border-white/10 bg-slate-900/70 px-4 py-3 text-white placeholder-slate-500 outline-none transition focus:border-violet-400 focus:ring-2 focus:ring-violet-500/30"
          />

          <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">Room</label>
          <div className="mb-5 flex items-center rounded-xl border border-white/10 bg-slate-900/70 px-4 focus-within:border-violet-400 focus-within:ring-2 focus-within:ring-violet-500/30">
            <span className="mr-1 select-none text-sm text-slate-500">chatarena.app/</span>
            <input
              value={room}
              onChange={(e) => setRoom(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
              maxLength={24}
              placeholder="lobby"
              className="w-full bg-transparent py-3 text-white placeholder-slate-500 outline-none"
            />
          </div>

          {err && <p className="mb-3 rounded-lg bg-rose-500/10 px-3 py-2 text-xs font-medium text-rose-300">{err}</p>}

          <button
            onClick={submit}
            className="w-full rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 py-3.5 font-bold text-white shadow-lg shadow-violet-900/40 transition hover:brightness-110 active:scale-[0.98]"
          >
            Join the arena →
          </button>

          <p className="mt-4 text-center text-[11px] leading-relaxed text-slate-500">
            No email, no password, no OTP. Search trains, movies, trips &amp; facts together — you always preview results before posting. History kept 2+ days.
          </p>
        </div>
      </div>
    </div>
  );
}