import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type {
  Attachment,
  BusEvent,
  GameId,
  LiveGame,
  Member,
  Message,
  SearchCard,
  User,
} from "../lib/types";
import { GAME_META, uid } from "../lib/types";
import {
  cleanText,
  claimLeadership,
  getProfanityFilter,
  getRetentionDays,
  isOnline,
  loadMembers,
  loadMessages,
  RETENTION_OPTIONS,
  roomLink,
  saveMembers,
  saveMessages,
  setProfanityFilter,
  setRetentionDays,
} from "../lib/store";
import {
  createGame,
  joinGame,
  mutateGame,
  playersFromMembers,
  readGame,
  writeGame,
} from "../lib/gameSync";
import {
  BOTS,
  BOT_GAME_CHEER,
  BOT_GENERIC,
  BOT_IDLE,
  BOT_REPLIES,
  gifUrl,
} from "../lib/data";
import { looksLikeQuestion } from "../lib/search";
import { summarize, type Summary } from "../lib/summarize";
import { EmojiPicker, GifPicker } from "./Pickers";
import GameOverlay from "./GameOverlay";
import SearchConsole from "./SearchConsole";
import SearchCardView from "./SearchCardView";
import GameLibrary from "./GameLibrary";
import { sounds } from "../lib/audio";

const GAME_IDS: GameId[] = [
  "bomb",
  "astro",
  "reactor",
  "cipher",
  "chain",
  "blitz",
  "codebreak",
  "story",
  "tictactoe",
  "connect4",
  "slide",
  "wikirace",
];
const HUMAN_ONLY_GAMES: GameId[] = ["slide", "wikirace", "controller", "npc", "desk"];
const REACTIONS = ["👍", "👎", "🤔", "❤️", "😂", "🎉", "🔥", "🚀"];

const SLASH_COMMANDS = [
  { cmd: "/game", label: "Launch Team Mini-Game", icon: "🎮", desc: "Locks chat & starts collaborative multiplayer game" },
  { cmd: "/trip", label: "Plan Trip Itinerary", icon: "🧭", desc: "Builds day-by-day itinerary & budget breakdown" },
  { cmd: "/train", label: "Search Trains (IRCTC)", icon: "🚆", desc: "Check trains, timings & seat quotas" },
  { cmd: "/flight", label: "Search Flights", icon: "✈️", desc: "Compare flight fares & schedules" },
  { cmd: "/movie", label: "Book Movie Tickets", icon: "🎬", desc: "Find cinema showtimes & trailer" },
  { cmd: "/stay", label: "Find Stays & Hotels", icon: "🏨", desc: "Search hotels, homestays & villas" },
  { cmd: "/weather", label: "Check Live Weather", icon: "🌦", desc: "Live temperature & 5-day forecast" },
  { cmd: "/food", label: "Restaurants & Cafes", icon: "🍔", desc: "Discover local food spots on maps" },
  { cmd: "/calc", label: "Currency & Bill Split", icon: "💱", desc: "Live FX converter & group split" },
  { cmd: "/ask", label: "Ask Web Answer", icon: "🌐", desc: "Instant answer from DuckDuckGo/Wikipedia" },
];

const PLACEHOLDERS = [
  "Message squad… (or type 'GAME' to start a team mission)",
  "Search anything… try 'trains Delhi to Jaipur tomorrow'",
  "Type '/trip plan a 3-day trip to Goa this weekend'",
  "Type '/movie tickets for Dune in Bengaluru tonight'",
  "Ask factual questions ending with '?' to search the web",
  "Type '/calc 500 usd in inr' to convert live currency",
];

const fmtTime = (ts: number) =>
  new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

const fmtDay = (ts: number) => {
  const d = new Date(ts),
    today = new Date();
  if (d.toDateString() === today.toDateString()) return "Today";
  const y = new Date(today);
  y.setDate(y.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  return d.toLocaleDateString([], { month: "short", day: "numeric" });
};

export default function ChatRoom({
  me,
  room,
  onLeave,
}: {
  me: User;
  room: string;
  onLeave: () => void;
}) {
  const [messages, setMessages] = useState<Message[]>(() => loadMessages(room));
  const [members, setMembers] = useState<Member[]>([]);
  const [game, setGame] = useState<LiveGame | null>(() => readGame(room));
  const [input, setInput] = useState("");
  const [picker, setPicker] = useState<"emoji" | "gif" | null>(null);
  const [typing, setTyping] = useState<
    Record<string, { name: string; until: number }>
  >({});
  const [showSidebar, setShowSidebar] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [searchOpen, setSearchOpen] = useState<string | null>(null);
  const [toast, setToast] = useState("");
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const [dictating, setDictating] = useState(false);
  const [unread, setUnread] = useState(0);
  const [reactFor, setReactFor] = useState<string | null>(null);
  const [retention, setRetention] = useState(getRetentionDays());
  const [profanity, setProfanity] = useState(getProfanityFilter());
  const [isLeader, setIsLeader] = useState(false);
  const [slashMenu, setSlashMenu] = useState(false);
  const [slashIdx, setSlashIdx] = useState(0);
  const [phIdx, setPhIdx] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [arcadeOpen, setArcadeOpen] = useState(false);

  const busRef = useRef<BroadcastChannel | null>(null);
  const leaderRef = useRef(false);
  const listRef = useRef<HTMLDivElement>(null);
  const atBottomRef = useRef(true);
  const fileRef = useRef<HTMLInputElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recTimerRef = useRef<number>(0);
  const speechRef = useRef<any>(null);
  const botTimersRef = useRef<number[]>([]);
  const idleCountRef = useRef(0);
  const gameRef = useRef(game);
  gameRef.current = game;
  const messagesRef = useRef(messages);
  messagesRef.current = messages;
  const membersRef = useRef(members);
  membersRef.current = members;

  const notify = useCallback((t: string) => {
    setToast(t);
    window.setTimeout(() => setToast(""), 2800);
  }, []);

  const post = useCallback((e: BusEvent) => busRef.current?.postMessage(e), []);

  const addMessage = useCallback(
    (m: Message, broadcast = true) => {
      setMessages((prev) =>
        prev.some((p) => p.id === m.id) ? prev : [...prev, m]
      );
      if (broadcast) post({ t: "msg", m });
    },
    [post]
  );

  const systemMsg = useCallback(
    (text: string) => {
      addMessage({
        id: uid(),
        kind: "system",
        userId: "system",
        name: "ChatArena",
        avatar: "",
        ts: Date.now(),
        text,
      });
    },
    [addMessage]
  );

  // Cycling placeholder effect
  useEffect(() => {
    const iv = setInterval(() => {
      setPhIdx((p) => (p + 1) % PLACEHOLDERS.length);
    }, 4500);
    return () => clearInterval(iv);
  }, []);

  /* ---------- Bot Simulation ---------- */
  const botSay = useCallback(
    (bot: Member, text: string, delay: number) => {
      const t1 = window.setTimeout(() => {
        post({
          t: "typing",
          uid: bot.id,
          name: bot.name,
          until: Date.now() + 2500,
        });
        setTyping((p) => ({
          ...p,
          [bot.id]: { name: bot.name, until: Date.now() + 2500 },
        }));
        const t2 = window.setTimeout(() => {
          sounds.playPop();
          addMessage({
            id: uid(),
            kind: "chat",
            userId: bot.id,
            name: bot.name,
            avatar: bot.avatar,
            ts: Date.now(),
            text,
          });
        }, 1400 + Math.random() * 900);
        botTimersRef.current.push(t2);
      }, delay);
      botTimersRef.current.push(t1);
    },
    [addMessage, post]
  );

  const maybeBotReply = useCallback(
    (text: string) => {
      if (!leaderRef.current || Math.random() > 0.55) return;
      const bot = BOTS[Math.floor(Math.random() * BOTS.length)];
      const rule = BOT_REPLIES.find((r) => r.match.test(text));
      const reply = rule
        ? rule.replies[Math.floor(Math.random() * rule.replies.length)]
        : BOT_GENERIC[Math.floor(Math.random() * BOT_GENERIC.length)];
      botSay(bot, reply, 900 + Math.random() * 1800);
    },
    [botSay]
  );

  /* ---------- Bus & Presence ---------- */
  useEffect(() => {
    const bus = new BroadcastChannel("chatarena_" + room);
    busRef.current = bus;
    bus.onmessage = (ev: MessageEvent<BusEvent>) => {
      const e = ev.data;
      if (e.t === "msg") {
        sounds.playPop();
        setMessages((prev) =>
          prev.some((p) => p.id === e.m.id) ? prev : [...prev, e.m]
        );
        if (!atBottomRef.current) setUnread((u) => u + 1);
      } else if (e.t === "update")
        setMessages((prev) => prev.map((p) => (p.id === e.m.id ? e.m : p)));
      else if (e.t === "del")
        setMessages((prev) => prev.filter((p) => p.id !== e.id));
      else if (e.t === "typing")
        setTyping((p) => ({
          ...p,
          [e.uid]: { name: e.name, until: e.until },
        }));
      else if (e.t === "game") {
        // Cache received state as well: subsequent moves/votes on this tab must
        // mutate the latest clip/board, including when storage quota is exceeded.
        const current = readGame(room);
        if (e.g && (!current || e.g.v >= current.v)) writeGame(room, e.g);
        if (!e.g) writeGame(room, null);
        setGame((cur) => (!e.g ? null : !cur || e.g.v >= cur.v ? e.g : cur));
      } else if (e.t === "presence") setMembers(loadMembers(room));
    };

    const existing = loadMembers(room);
    const withBots = [
      ...existing.filter((m) => !m.bot),
      ...BOTS.map((b) => ({ ...b, lastSeen: Date.now() })),
    ];
    const next = withBots.some((m) => m.id === me.id)
      ? withBots.map((m) =>
          m.id === me.id
            ? { ...m, name: me.name, avatar: me.avatar, lastSeen: Date.now() }
            : m
        )
      : [
          ...withBots,
          {
            ...me,
            lastSeen: Date.now(),
            admin: !withBots.some((m) => m.admin && !m.bot),
          },
        ];
    saveMembers(room, next);
    setMembers(next);
    post({ t: "presence" });

    leaderRef.current = claimLeadership(room);
    setIsLeader(leaderRef.current);

    if (!existing.some((m) => m.id === me.id)) {
      addMessage({
        id: uid(),
        kind: "system",
        userId: "system",
        name: "ChatArena",
        avatar: "",
        ts: Date.now(),
        text: `👋 ${me.name} joined the room`,
      });
      if (leaderRef.current) {
        const bot = BOTS[Math.floor(Math.random() * BOTS.length)];
        botSay(
          bot,
          `Welcome ${me.name}! 🎉 Type 'GAME' for squad mini-games or hit 🔎 to research trips & movies together.`,
          1800
        );
      }
    }

    const heartbeat = window.setInterval(() => {
      leaderRef.current = claimLeadership(room);
      setIsLeader(leaderRef.current);
      const cur = loadMembers(room);
      const updated = cur.map((m) =>
        m.id === me.id ? { ...m, lastSeen: Date.now() } : m
      );
      if (!updated.some((m) => m.id === me.id))
        updated.push({ ...me, lastSeen: Date.now() });
      saveMembers(room, updated);
      setMembers(updated);
      post({ t: "presence" });
      setTyping((p) =>
        Object.fromEntries(
          Object.entries(p).filter(([, v]) => v.until > Date.now())
        )
      );
      const g = readGame(room);
      setGame((c) => (!g ? null : !c || g.v >= c.v ? g : c));
    }, 4000);

    const idle = window.setInterval(() => {
      if (!leaderRef.current || gameRef.current || idleCountRef.current >= 4)
        return;
      const last = messagesRef.current[messagesRef.current.length - 1];
      if (last && Date.now() - last.ts > 50000) {
        idleCountRef.current++;
        const bot = BOTS[Math.floor(Math.random() * BOTS.length)];
        botSay(
          bot,
          BOT_IDLE[Math.floor(Math.random() * BOT_IDLE.length)],
          500
        );
      }
    }, 30000);

    return () => {
      clearInterval(heartbeat);
      clearInterval(idle);
      botTimersRef.current.forEach(clearTimeout);
      bus.close();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room, me.id]);

  useEffect(() => {
    saveMessages(room, messages);
  }, [messages, room]);

  useEffect(() => {
    if (atBottomRef.current) {
      listRef.current?.scrollTo({
        top: listRef.current.scrollHeight,
        behavior: "smooth",
      });
      setUnread(0);
    }
  }, [messages, typing]);

  const onScroll = () => {
    const el = listRef.current;
    if (!el) return;
    atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    if (atBottomRef.current) setUnread(0);
  };

  /* ---------- Game Operations ---------- */
  const syncGame = useCallback(
    (g: LiveGame | null) => {
      setGame(g);
      post({ t: "game", g });
    },
    [post]
  );

  const mutate = useCallback(
    (fn: (g: LiveGame) => LiveGame | null) => {
      const g = mutateGame(room, fn);
      syncGame(g);
    },
    [room, syncGame]
  );

  const startGame = useCallback(
    (byName: string, requested?: GameId) => {
      sounds.playGameTrigger();
      const online = membersRef.current.filter(isOnline);
      const id = requested || GAME_IDS[Math.floor(Math.random() * GAME_IDS.length)];
      let players = playersFromMembers(online, isOnline);
      // Camera challenges, sliding relay and WikiRace use real human turns;
      // simulated members still cheer in the room but never fake a camera or web race.
      if (HUMAN_ONLY_GAMES.includes(id)) players = players.filter((p) => !p.bot);
      if (!players.length) players = [{ uid: me.id, name: me.name, avatar: me.avatar, score: 0 }];
      const g = createGame(
        id,
        Math.floor(Math.random() * 1e9),
        byName,
        players
      );
      writeGame(room, g);
      syncGame(g);
      const meta = GAME_META[g.id];
      systemMsg(
        `🎮 ${byName} initiated ${meta.name} ${meta.emoji} — Squad multiplayer mission for ${players.length} players! Chat locked until completed.`
      );
    },
    [room, syncGame, systemMsg, me]
  );

  const finishGame = useCallback(
    (result: string, bonus?: string) => {
      const existing = readGame(room);
      if (!existing || existing.phase === "done") return;
      const g = mutateGame(room, (cur) => ({
        ...cur,
        phase: "done",
        result,
        bonus,
      }));
      syncGame(g);
      systemMsg(`🏆 Squad mission result: ${result} — Chat unlocked! 💬`);
      if (bonus) systemMsg(bonus);
      window.setTimeout(() => {
        writeGame(room, null);
        syncGame(null);
      }, 4200);
      if (leaderRef.current) {
        const bot = BOTS[Math.floor(Math.random() * BOTS.length)];
        botSay(
          bot,
          BOT_GAME_CHEER[Math.floor(Math.random() * BOT_GAME_CHEER.length)] +
            " Fantastic teamwork! 🏆",
          5000
        );
      }
    },
    [room, syncGame, systemMsg, botSay]
  );

  // Auto-join ongoing squad game
  useEffect(() => {
    if (
      game &&
      game.phase === "play" &&
      !game.players.some((p) => p.uid === me.id)
    ) {
      const g = joinGame(room, {
        uid: me.id,
        name: me.name,
        avatar: me.avatar,
        score: 0,
      });
      if (g) syncGame(g);
    }
  }, [game, me, room, syncGame]);

  /* ---------- Sending Messages & Search Triggers ---------- */
  const send = useCallback(() => {
    const raw = input.trim();
    if (!raw || gameRef.current) return;
    setInput("");
    setPicker(null);
    setSlashMenu(false);

    if (raw === "GAME") {
      sounds.playGameTrigger();
      addMessage({
        id: uid(),
        kind: "chat",
        userId: me.id,
        name: me.name,
        avatar: me.avatar,
        ts: Date.now(),
        text: "GAME",
      });
      startGame(me.name);
      return;
    }

    if (raw === "/game") {
      setArcadeOpen(true);
      return;
    }

    if (/^\/(ask|search|find|trip|train|flight|movie|stay|weather|food|calc)\b/i.test(raw)) {
      sounds.playPop();
      setSearchOpen(raw.replace(/^\/\w+\s*/, ""));
      return;
    }

    sounds.playSend();
    addMessage({
      id: uid(),
      kind: "chat",
      userId: me.id,
      name: me.name,
      avatar: me.avatar,
      ts: Date.now(),
      text: cleanText(raw),
    });

    if (looksLikeQuestion(raw)) {
      setSearchOpen(raw);
      notify("🔎 Opened Search Console — preview results before posting!");
    } else {
      maybeBotReply(raw);
    }
  }, [input, me, addMessage, startGame, maybeBotReply, notify]);

  const shareCard = useCallback(
    (card: SearchCard) => {
      setSearchOpen(null);
      sounds.playSend();
      addMessage({
        id: uid(),
        kind: "ai",
        userId: me.id,
        name: me.name,
        avatar: me.avatar,
        ts: Date.now(),
        card,
        reactions: {},
      });
      notify("📤 Shared search card with room");
    },
    [addMessage, me, notify]
  );

  const sendAttachment = useCallback(
    (att: Attachment, text?: string) => {
      if (gameRef.current) return;
      sounds.playSend();
      addMessage({
        id: uid(),
        kind: "chat",
        userId: me.id,
        name: me.name,
        avatar: me.avatar,
        ts: Date.now(),
        text,
        attachment: att,
      });
      maybeBotReply(
        att.type === "gif" ? "lol" : att.type === "audio" ? "voice" : "file"
      );
    },
    [me, addMessage, maybeBotReply]
  );

  const react = useCallback(
    (m: Message, emoji: string) => {
      sounds.playPop();
      setReactFor(null);
      setMessages((prev) =>
        prev.map((p) => {
          if (p.id !== m.id) return p;
          const r = { ...(p.reactions || {}) };
          const list = r[emoji] || [];
          r[emoji] = list.includes(me.name)
            ? list.filter((n) => n !== me.name)
            : [...list, me.name];
          if (!r[emoji].length) delete r[emoji];
          const updated = { ...p, reactions: r };
          post({ t: "update", m: updated });
          return updated;
        })
      );
    },
    [me.name, post]
  );

  const onTyping = (v: string) => {
    setInput(v);
    if (v.startsWith("/")) {
      setSlashMenu(true);
      setSlashIdx(0);
    } else {
      setSlashMenu(false);
    }
    post({ t: "typing", uid: me.id, name: me.name, until: Date.now() + 2500 });
  };

  const handleSlashSelect = (cmd: string) => {
    sounds.playPop();
    setSlashMenu(false);
    if (cmd === "/game") {
      setArcadeOpen(true);
      setInput("");
    } else {
      setSearchOpen("");
      setInput("");
    }
  };

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    if (f.size > 4 * 1024 * 1024)
      return notify("File too large — keep under 4 MB");
    const reader = new FileReader();
    reader.onload = () => {
      const ephemeral = f.size > 350 * 1024;
      sendAttachment({
        type: f.type.startsWith("image/") ? "image" : "file",
        name: f.name,
        url: String(reader.result),
        mime: f.type || "application/octet-stream",
        size: f.size,
        ephemeral,
      });
      if (ephemeral) notify("Large file shared for this session");
    };
    reader.readAsDataURL(f);
  };

  const toggleRecording = async () => {
    if (recording) return recorderRef.current?.stop();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
      });
      const rec = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      rec.ondataavailable = (e) => chunks.push(e.data);
      rec.onstop = () => {
        clearInterval(recTimerRef.current);
        setRecording(false);
        setRecSecs(0);
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, {
          type: rec.mimeType || "audio/webm",
        });
        if (blob.size < 500) return;
        const reader = new FileReader();
        reader.onload = () =>
          sendAttachment({
            type: "audio",
            name: "Voice note",
            url: String(reader.result),
            mime: blob.type,
            size: blob.size,
            ephemeral: blob.size > 350 * 1024,
          });
        reader.readAsDataURL(blob);
      };
      rec.start();
      recorderRef.current = rec;
      setRecording(true);
      recTimerRef.current = window.setInterval(
        () =>
          setRecSecs((s) => {
            if (s >= 59) rec.stop();
            return s + 1;
          }),
        1000
      );
    } catch {
      notify("Microphone access denied");
    }
  };

  const toggleDictation = () => {
    if (dictating) {
      speechRef.current?.stop();
      return setDictating(false);
    }
    const SR =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (!SR) return notify("Voice-to-text needs Chrome or Edge");
    sounds.playPop();
    const rec = new SR();
    rec.lang = "en-US";
    rec.interimResults = true;
    rec.continuous = false;
    const base = input;
    rec.onresult = (e: any) => {
      let t = "";
      for (let i = 0; i < e.results.length; i++) t += e.results[i][0].transcript;
      setInput((base ? base + " " : "") + t);
    };
    rec.onend = () => setDictating(false);
    rec.onerror = () => {
      setDictating(false);
      notify("Couldn't hear audio");
    };
    rec.start();
    speechRef.current = rec;
    setDictating(true);
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(roomLink(room));
      sounds.playSuccess();
      notify("🔗 Invite link copied to clipboard!");
    } catch {
      notify(roomLink(room));
    }
  };

  const deleteMsg = (m: Message) => {
    if (m.userId !== me.id) return notify("🚩 Reported to room owner");
    setMessages((prev) => prev.filter((p) => p.id !== m.id));
    post({ t: "del", id: m.id });
  };

  const typingNames = useMemo(
    () =>
      Object.entries(typing)
        .filter(([id, v]) => id !== me.id && v.until > Date.now())
        .map(([, v]) => v.name),
    [typing, me.id]
  );

  const onlineCount = members.filter(isOnline).length;

  return (
    <div className="flex h-screen flex-col bg-slate-950 text-white selection:bg-violet-600 selection:text-white">
      {/* Top Navbar */}
      <header className="flex items-center gap-2 border-b border-white/10 bg-slate-900/90 px-3 py-2.5 backdrop-blur-md sm:gap-3 sm:px-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-rose-500 text-xl shadow-lg shadow-violet-950">
          ⚡
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <h1 className="truncate font-black text-white leading-tight">
              ChatArena
            </h1>
            <span className="rounded-lg bg-violet-500/20 px-2 py-0.5 font-mono text-xs font-bold text-violet-300">
              /{room}
            </span>
          </div>
          <p className="flex items-center gap-1 text-[11px] text-slate-400">
            <span className="inline-block h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>{onlineCount}/20 online</span>
            {game && (
              <span className="ml-1 rounded bg-amber-500/20 px-1 font-bold text-amber-300">
                🔒 {GAME_META[game.id].emoji} {GAME_META[game.id].name} in progress
              </span>
            )}
          </p>
        </div>

        {/* Expressive Search Action */}
        <button
          onClick={() => {
            sounds.playPop();
            setSearchOpen("");
          }}
          title="Search trains, flights, movies, trips, weather"
          className="group flex items-center gap-1.5 rounded-2xl border border-teal-400/40 bg-gradient-to-r from-teal-500/20 to-teal-400/10 px-3.5 py-2 text-xs font-black text-teal-300 shadow-md shadow-teal-950/40 transition hover:border-teal-400 hover:bg-teal-500/25 active:scale-95"
        >
          <span className="text-sm transition group-hover:scale-125">🔎</span>
          <span className="hidden sm:inline">Search &amp; Plan</span>
        </button>

        {/* Squad arcade: choose from all 15 games */}
        <button
          onClick={() => { sounds.playPop(); setArcadeOpen(true); }}
          title="Open Squad Arcade — 15 games"
          className="rounded-2xl border border-amber-400/40 bg-amber-400/15 px-3 py-2 font-mono text-xs font-black text-amber-300 shadow-md shadow-amber-950/40 transition hover:bg-amber-400/25 active:scale-95"
        >
          🎮 <span className="hidden sm:inline">Arcade</span>
        </button>

        {/* Share Invite */}
        <button
          onClick={copyLink}
          className="rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-3.5 py-2 text-xs font-bold text-white shadow-md shadow-violet-950/50 transition hover:brightness-110 active:scale-95"
        >
          🔗<span className="ml-1 hidden sm:inline">Invite</span>
        </button>

        {/* Settings & Mute Audio */}
        <div className="relative">
          <button
            onClick={() => {
              sounds.playPop();
              setShowSettings((s) => !s);
            }}
            className="rounded-xl bg-slate-800/80 p-2 text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            ⚙️
          </button>
          {showSettings && (
            <div className="absolute right-0 top-full z-40 mt-2 w-72 rounded-3xl border border-white/10 bg-slate-900 p-4 shadow-2xl backdrop-blur-xl">
              <p className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">
                History Retention Window
              </p>
              <div className="mb-3 flex gap-1.5">
                {RETENTION_OPTIONS.map((d) => (
                  <button
                    key={d}
                    onClick={() => {
                      sounds.playPop();
                      setRetentionDays(d);
                      setRetention(d);
                      notify(`History preserved for ${d} days`);
                    }}
                    className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
                      retention === d
                        ? "bg-violet-600 text-white shadow"
                        : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                    }`}
                  >
                    {d} Days
                  </button>
                ))}
              </div>

              <label className="mb-3 flex cursor-pointer items-center justify-between text-xs font-semibold text-slate-300">
                <span>Sound FX Audio</span>
                <button
                  onClick={() => {
                    sounds.enabled = !soundEnabled;
                    setSoundEnabled(!soundEnabled);
                  }}
                  className={`h-6 w-11 rounded-full p-0.5 transition ${
                    soundEnabled ? "bg-violet-600" : "bg-slate-700"
                  }`}
                >
                  <span
                    className={`block h-5 w-5 rounded-full bg-white transition ${
                      soundEnabled ? "translate-x-5" : ""
                    }`}
                  />
                </button>
              </label>

              <label className="flex cursor-pointer items-center justify-between text-xs font-semibold text-slate-300">
                <span>Profanity Filter</span>
                <button
                  onClick={() => {
                    sounds.playPop();
                    setProfanityFilter(!profanity);
                    setProfanity(!profanity);
                  }}
                  className={`h-6 w-11 rounded-full p-0.5 transition ${
                    profanity ? "bg-violet-600" : "bg-slate-700"
                  }`}
                >
                  <span
                    className={`block h-5 w-5 rounded-full bg-white transition ${
                      profanity ? "translate-x-5" : ""
                    }`}
                  />
                </button>
              </label>

              <button
                onClick={onLeave}
                className="mt-4 w-full rounded-2xl bg-rose-500/10 py-2.5 text-xs font-bold text-rose-300 hover:bg-rose-500/20"
              >
                Leave Room
              </button>
            </div>
          )}
        </div>

        {/* Mobile Sidebar Toggle */}
        <button
          onClick={() => setShowSidebar((s) => !s)}
          className="rounded-xl bg-slate-800 p-2 text-slate-300 hover:bg-slate-700 lg:hidden"
        >
          👥
        </button>
      </header>

      {/* Main Container */}
      <div className="flex min-h-0 flex-1">
        {/* Messages Feed */}
        <main className="relative flex min-w-0 flex-1 flex-col">
          <div
            ref={listRef}
            onScroll={onScroll}
            className="chat-scroll flex-1 space-y-1.5 overflow-y-auto px-3 py-4 sm:px-6"
          >
            {messages.length === 0 && (
              <div className="flex h-full flex-col items-center justify-center gap-3 text-center text-slate-500 py-12">
                <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-slate-900 border border-white/5 text-4xl shadow-inner">
                  💬
                </div>
                <div>
                  <p className="font-bold text-slate-300 text-base">
                    Welcome to /{room}!
                  </p>
                  <p className="mx-auto mt-1 max-w-sm text-xs leading-relaxed text-slate-400">
                    Chat normally · Type <b className="text-amber-300 font-mono">GAME</b> for team mini-games · Tap <b className="text-teal-300 font-semibold">🔎 Search</b> for live trains, flights, movies &amp; trips.
                  </p>
                </div>
              </div>
            )}

            {messages.map((m, i) => {
              const prev = messages[i - 1];
              return (
                <div key={m.id}>
                  {(!prev || fmtDay(prev.ts) !== fmtDay(m.ts)) && (
                    <div className="my-4 flex items-center gap-3">
                      <div className="h-px flex-1 bg-white/10" />
                      <span className="rounded-full bg-slate-900 px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                        {fmtDay(m.ts)}
                      </span>
                      <div className="h-px flex-1 bg-white/10" />
                    </div>
                  )}
                  <MessageRow
                    m={m}
                    mine={m.userId === me.id}
                    onDelete={() => deleteMsg(m)}
                    onReact={(e) => react(m, e)}
                    pickerOpen={reactFor === m.id}
                    togglePicker={() =>
                      setReactFor(reactFor === m.id ? null : m.id)
                    }
                  />
                </div>
              );
            })}

            {typingNames.length > 0 && (
              <div className="flex items-center gap-2 px-3 pt-1 text-xs text-slate-400">
                <span className="flex gap-0.5">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="typing-dot h-1.5 w-1.5 rounded-full bg-violet-400"
                      style={{ animationDelay: `${i * 0.15}s` }}
                    />
                  ))}
                </span>
                <span>
                  {typingNames.join(", ")} {typingNames.length === 1 ? "is" : "are"}{" "}
                  typing…
                </span>
              </div>
            )}
          </div>

          {unread > 0 && (
            <button
              onClick={() => {
                sounds.playPop();
                listRef.current?.scrollTo({
                  top: listRef.current.scrollHeight,
                  behavior: "smooth",
                });
                setUnread(0);
              }}
              className="absolute bottom-32 left-1/2 z-30 -translate-x-1/2 rounded-full bg-violet-600 px-5 py-2 text-xs font-black shadow-2xl transition hover:bg-violet-500 active:scale-95"
            >
              ↓ {unread} new message{unread > 1 ? "s" : ""}
            </button>
          )}

          {/* Slash Commands Dropdown Menu */}
          {slashMenu && (
            <div className="absolute bottom-20 left-4 z-40 w-80 overflow-hidden rounded-3xl border border-white/10 bg-slate-900/95 p-2 shadow-2xl backdrop-blur-xl sm:left-6">
              <p className="px-3 py-1 text-[10px] font-black uppercase tracking-widest text-slate-500">
                Slash Commands
              </p>
              <div className="max-h-56 overflow-y-auto space-y-0.5">
                {SLASH_COMMANDS.map((s, idx) => (
                  <button
                    key={s.cmd}
                    onClick={() => handleSlashSelect(s.cmd)}
                    className={`flex w-full items-center gap-2.5 rounded-2xl px-3 py-2 text-left transition ${
                      idx === slashIdx
                        ? "bg-violet-600 text-white"
                        : "hover:bg-slate-800 text-slate-300"
                    }`}
                  >
                    <span className="text-lg">{s.icon}</span>
                    <div className="min-w-0 flex-1">
                      <p className="font-bold text-xs">{s.label}</p>
                      <p className="truncate text-[10px] text-slate-400">
                        {s.desc}
                      </p>
                    </div>
                    <span className="font-mono text-[10px] opacity-70">
                      {s.cmd}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Composer Input Bar */}
          <div className="border-t border-white/10 bg-slate-900/90 px-3 pb-3 pt-2.5 backdrop-blur-md sm:px-6">
            {game ? (
              <div className="flex items-center justify-center gap-2 rounded-2xl border border-amber-400/30 bg-amber-400/10 py-3.5 text-sm font-bold text-amber-300 shadow-inner">
                🔒 Chat locked for Squad Mission: {GAME_META[game.id].emoji}{" "}
                {GAME_META[game.id].name} ({GAME_META[game.id].tag})
              </div>
            ) : (
              <>
                <div className="relative flex items-end gap-1.5">
                  {picker === "emoji" && (
                    <EmojiPicker
                      onPick={(e) => setInput((v) => v + e)}
                      onClose={() => setPicker(null)}
                    />
                  )}
                  {picker === "gif" && (
                    <GifPicker
                      onClose={() => setPicker(null)}
                      onPick={(id, label) => {
                        setPicker(null);
                        sendAttachment({
                          type: "gif",
                          name: label,
                          url: gifUrl(id),
                          mime: "image/gif",
                        });
                      }}
                    />
                  )}

                  <IconBtn
                    active={picker === "emoji"}
                    onClick={() => setPicker(picker === "emoji" ? null : "emoji")}
                    title="Emoji Picker"
                  >
                    😀
                  </IconBtn>
                  <IconBtn
                    active={picker === "gif"}
                    onClick={() => setPicker(picker === "gif" ? null : "gif")}
                    title="GIF Library"
                  >
                    <span className="text-[10px] font-black">GIF</span>
                  </IconBtn>
                  <IconBtn
                    onClick={() => fileRef.current?.click()}
                    title="Attach File or PDF"
                  >
                    📎
                  </IconBtn>
                  <input
                    ref={fileRef}
                    type="file"
                    hidden
                    onChange={(e) => {
                      onFile(e.target.files?.[0]);
                      e.target.value = "";
                    }}
                  />
                  <IconBtn
                    onClick={() => {
                      sounds.playPop();
                      setSearchOpen(input.trim());
                    }}
                    title="Search & Plan (Trains, Movies, Trips, Stays)"
                  >
                    <span className="text-teal-300">🔎</span>
                  </IconBtn>
                  <IconBtn
                    active={dictating}
                    onClick={toggleDictation}
                    title="Voice-to-Text Dictation"
                  >
                    {dictating ? "🔴" : "🗣️"}
                  </IconBtn>

                  {recording ? (
                    <div className="flex flex-1 items-center gap-3 rounded-2xl border border-rose-500/50 bg-rose-500/10 px-4 py-2.5">
                      <span className="h-3 w-3 animate-pulse rounded-full bg-rose-500" />
                      <span className="font-mono text-sm font-bold text-rose-300">
                        Recording… 0:{String(recSecs).padStart(2, "0")}
                      </span>
                      <button
                        onClick={toggleRecording}
                        className="ml-auto rounded-xl bg-rose-600 px-3.5 py-1 text-xs font-bold text-white hover:bg-rose-500"
                      >
                        ■ Send
                      </button>
                    </div>
                  ) : (
                    <textarea
                      value={input}
                      onChange={(e) => onTyping(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          send();
                        }
                      }}
                      rows={1}
                      placeholder={
                        dictating ? "Listening to your voice… 🎤" : PLACEHOLDERS[phIdx]
                      }
                      className="max-h-28 min-h-[44px] flex-1 resize-none rounded-2xl border border-white/10 bg-slate-800/90 px-4 py-2.5 text-[15px] placeholder-slate-500 outline-none transition focus:border-violet-400 focus:ring-2 focus:ring-violet-500/20"
                    />
                  )}

                  <IconBtn
                    active={recording}
                    onClick={toggleRecording}
                    title="Record Voice Note"
                  >
                    🎤
                  </IconBtn>
                  <button
                    onClick={send}
                    disabled={!input.trim()}
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 via-fuchsia-600 to-rose-600 text-lg text-white shadow-lg shadow-violet-950 transition hover:brightness-110 active:scale-95 disabled:opacity-40"
                  >
                    ➤
                  </button>
                </div>

                <div className="mt-2 flex items-center justify-between gap-2">
                  <p className="hidden truncate text-[11px] text-slate-400 sm:block">
                    💡 Type <span className="font-mono font-bold text-violet-300">/</span> for commands · <span className="font-mono font-bold text-amber-300">GAME</span> = squad game · <span className="font-mono font-bold text-teal-300">?</span> = web search preview
                  </p>
                  <button
                    onClick={() => {
                      sounds.playPop();
                      setSummary(summarize(messages));
                    }}
                    className="ml-auto shrink-0 rounded-xl border border-violet-500/40 bg-violet-500/10 px-3.5 py-1.5 text-xs font-bold text-violet-300 transition hover:bg-violet-500/20 active:scale-95"
                  >
                    ✨ Summarize this chat
                  </button>
                </div>
              </>
            )}
          </div>
        </main>

        {/* Members & Details Sidebar */}
        <aside
          className={`${
            showSidebar
              ? "absolute inset-y-0 right-0 z-40 flex w-72 shadow-2xl"
              : "hidden"
          } flex-col border-l border-white/10 bg-slate-900/95 lg:static lg:flex lg:w-72`}
        >
          <div className="border-b border-white/10 p-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Shareable Room Link
              </p>
              <button
                onClick={() => setShowSidebar(false)}
                className="text-slate-400 hover:text-white lg:hidden"
              >
                ✕
              </button>
            </div>
            <button
              onClick={copyLink}
              className="w-full truncate rounded-2xl border border-white/10 bg-slate-800/80 px-3.5 py-2 text-left font-mono text-xs text-violet-300 transition hover:border-violet-400"
            >
              🔗 chatarena.app/{room}
            </button>
            <p className="mt-1.5 text-[11px] text-slate-400 leading-snug">
              Open in multiple tabs/devices — online teammates automatically join the same team missions &amp; searches in real time.
            </p>
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            <p className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">
              Members Online ({onlineCount}/20)
            </p>
            <div className="space-y-2">
              {[...members]
                .sort(
                  (a, b) =>
                    Number(isOnline(b)) - Number(isOnline(a))
                )
                .map((m) => (
                  <div
                    key={m.id}
                    className="flex items-center gap-2.5 rounded-2xl bg-slate-800/40 p-2 border border-white/5"
                  >
                    <div className="relative shrink-0">
                      <img
                        src={m.avatar}
                        alt=""
                        className="h-9 w-9 rounded-full object-cover"
                      />
                      <span
                        className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-slate-900 ${
                          isOnline(m) ? "bg-emerald-400" : "bg-slate-600"
                        }`}
                      />
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-white">
                        {m.name}{" "}
                        {m.id === me.id && (
                          <span className="text-xs text-slate-400">(you)</span>
                        )}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {m.admin
                          ? "👑 Room Host"
                          : m.bot
                          ? "Squad Regular"
                          : isOnline(m)
                          ? "Online"
                          : "Away"}
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          <div className="border-t border-white/10 p-4 text-[11px] leading-relaxed text-slate-400">
            🔒 History kept for {retention} days · Voice notes &amp; attachments stay private in room.
          </div>
        </aside>
      </div>

      {/* Overlays & Modals */}
      {arcadeOpen && !game && (
        <GameLibrary
          onClose={() => setArcadeOpen(false)}
          onPick={(id) => {
            setArcadeOpen(false);
            startGame(me.name, id || undefined);
          }}
        />
      )}
      {game && (
        <GameOverlay
          g={game}
          me={me}
          isLeader={isLeader}
          mutate={mutate}
          finish={finishGame}
        />
      )}

      {searchOpen !== null && (
        <SearchConsole
          initialQuery={searchOpen}
          onClose={() => setSearchOpen(null)}
          onShare={shareCard}
        />
      )}

      {summary && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-md"
          onClick={() => setSummary(null)}
        >
          <div
            className="max-h-[88vh] w-full max-w-xl overflow-y-auto rounded-3xl border border-white/10 bg-slate-900 p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-start justify-between">
              <div>
                <h2 className="text-2xl font-black text-white">
                  ✨ Session Summary
                </h2>
                <p className="text-xs text-slate-400">
                  Room /{room} · Analysis of last {retention} days
                </p>
              </div>
              <button
                onClick={() => setSummary(null)}
                className="rounded-xl bg-slate-800 p-2 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <p className="mb-4 rounded-2xl border border-violet-500/30 bg-violet-500/10 p-4 text-sm leading-relaxed text-violet-100">
              {summary.headline}
            </p>

            <div className="mb-4 grid grid-cols-3 gap-2 text-center">
              {[
                ["💬", summary.stats.humans, "messages"],
                ["👥", summary.stats.participants.length, "participants"],
                ["🎮", summary.stats.games, "squad games"],
              ].map(([icon, num, label]) => (
                <div key={String(label)} className="rounded-2xl bg-slate-800/70 p-3">
                  <p className="text-lg">{icon}</p>
                  <p className="text-xl font-black text-white">{num}</p>
                  <p className="text-[10px] uppercase tracking-wider text-slate-400">
                    {label}
                  </p>
                </div>
              ))}
            </div>

            {summary.topics.length > 0 && (
              <Section title="🏷 Key Topics">
                <div className="flex flex-wrap gap-1.5">
                  {summary.topics.map((t) => (
                    <span
                      key={t}
                      className="rounded-full bg-slate-800 px-3 py-1 text-xs font-semibold text-violet-300"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </Section>
            )}

            {summary.shared.length > 0 && (
              <Section title="🔎 Shared Research & Plans">
                {summary.shared.map((s, i) => (
                  <li key={i}>
                    <b>{s.label}:</b> "{s.query}"
                    {s.note && (
                      <span className="text-violet-300 font-medium">
                        {" "}
                        — {s.note}
                      </span>
                    )}
                  </li>
                ))}
              </Section>
            )}

            {summary.keyPoints.length > 0 && (
              <Section title="📌 Key Highlights">
                {summary.keyPoints.map((k, i) => (
                  <li key={i}>{k}</li>
                ))}
              </Section>
            )}

            {summary.questions.length > 0 && (
              <Section title="❓ Questions & Inquiries">
                {summary.questions.map((q, i) => (
                  <li key={i}>
                    {q.q}
                    {q.a && (
                      <span className="block text-emerald-300/90 text-xs mt-0.5">
                        → {q.a}
                      </span>
                    )}
                  </li>
                ))}
              </Section>
            )}

            {summary.decisions.length > 0 && (
              <Section title="🤝 Squad Agreements & Plans">
                {summary.decisions.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </Section>
            )}

            {summary.games.length > 0 && (
              <Section title="🎮 Squad Game Results">
                {summary.games.map((g, i) => (
                  <li key={i}>{g}</li>
                ))}
              </Section>
            )}
          </div>
        </div>
      )}

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[60] -translate-x-1/2 rounded-2xl border border-white/10 bg-slate-800/95 px-5 py-3 text-sm font-bold text-white shadow-2xl backdrop-blur-md">
          {toast}
        </div>
      )}
    </div>
  );
}

function IconBtn({
  children,
  onClick,
  title,
  active,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  active?: boolean;
}) {
  return (
    <button
      onClick={() => {
        sounds.playPop();
        onClick();
      }}
      title={title}
      className={`flex h-11 w-9 shrink-0 items-center justify-center rounded-2xl text-lg transition active:scale-95 sm:w-10 ${
        active
          ? "bg-violet-600/40 text-white ring-1 ring-violet-400"
          : "text-slate-400 hover:bg-slate-800/80 hover:text-white"
      }`}
    >
      {children}
    </button>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mb-4">
      <p className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">
        {title}
      </p>
      <ul className="list-inside list-disc space-y-1.5 text-sm leading-relaxed text-slate-300">
        {children}
      </ul>
    </div>
  );
}

interface RowProps {
  m: Message;
  mine: boolean;
  onDelete: () => void;
  onReact: (e: string) => void;
  pickerOpen: boolean;
  togglePicker: () => void;
}

function Reactions({
  m,
  onReact,
}: {
  m: Message;
  onReact: (e: string) => void;
}) {
  if (!m.reactions || !Object.keys(m.reactions).length) return null;
  return (
    <div className="mt-1.5 flex flex-wrap gap-1">
      {Object.entries(m.reactions).map(([e, names]) => (
        <button
          key={e}
          onClick={() => onReact(e)}
          title={names.join(", ")}
          className="rounded-full border border-white/10 bg-slate-800/90 px-2.5 py-0.5 text-xs font-bold text-slate-200 shadow hover:border-violet-400"
        >
          {e} {names.length}
        </button>
      ))}
    </div>
  );
}

function MessageRow({
  m,
  mine,
  onDelete,
  onReact,
  pickerOpen,
  togglePicker,
}: RowProps) {
  if (m.kind === "system")
    return (
      <div className="my-2.5 flex justify-center">
        <span className="max-w-[92%] rounded-2xl border border-white/10 bg-slate-800/60 px-4 py-1.5 text-center text-xs font-medium text-slate-400">
          {m.text}
        </span>
      </div>
    );

  if (m.kind === "ai" && m.card)
    return (
      <div
        className={`group my-2 flex ${
          mine ? "justify-end" : "justify-start"
        }`}
      >
        <div className="relative w-full max-w-[94%] sm:max-w-[84%]">
          <p
            className={`mb-1 text-[11px] font-bold ${
              mine ? "text-right text-slate-400" : "text-violet-300"
            }`}
          >
            {mine ? "You shared research" : `${m.name} shared research`} ·{" "}
            {fmtTime(m.ts)}
          </p>
          <SearchCardView card={m.card} />
          <div className="mt-2 flex items-center gap-1.5">
            {(m.card.askVote ? ["👍", "👎", "🤔"] : REACTIONS.slice(0, 4)).map(
              (e) => (
                <button
                  key={e}
                  onClick={() => onReact(e)}
                  className="rounded-xl border border-white/5 bg-slate-800/80 px-2.5 py-1 text-sm shadow transition hover:scale-110 hover:bg-slate-700"
                >
                  {e}
                </button>
              )
            )}
            <Reactions m={m} onReact={onReact} />
          </div>
        </div>
      </div>
    );

  const att = m.attachment;
  return (
    <div
      className={`group flex items-end gap-2 py-1 ${
        mine ? "flex-row-reverse" : ""
      }`}
    >
      {!mine && (
        <img
          src={m.avatar}
          alt={m.name}
          className="h-8 w-8 shrink-0 rounded-full object-cover"
        />
      )}
      <div className="relative max-w-[85%] sm:max-w-[70%]">
        {!mine && (
          <p className="mb-0.5 ml-1 text-[11px] font-bold text-violet-300">
            {m.name}
          </p>
        )}
        <div
          className={`rounded-3xl px-4 py-2.5 shadow-md ${
            mine
              ? "rounded-br-sm bg-gradient-to-br from-violet-600 to-indigo-600 text-white"
              : "rounded-bl-sm bg-slate-800/90 text-slate-100"
          } ${m.text === "GAME" ? "ring-2 ring-amber-400/80" : ""}`}
        >
          {m.text === "GAME" ? (
            <p className="text-center font-mono text-xl font-black tracking-widest text-amber-300">
              🎮 GAME
            </p>
          ) : (
            m.text && (
              <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
                {m.text}
              </p>
            )
          )}
          {att && (
            <div className={m.text ? "mt-2.5" : ""}>
              {att.type === "image" &&
                (att.url ? (
                  <img
                    src={att.url}
                    alt={att.name}
                    className="max-h-64 rounded-2xl shadow"
                  />
                ) : (
                  <Expired label="Image" />
                ))}
              {att.type === "gif" && (
                <img
                  src={att.url}
                  alt={att.name}
                  className="max-h-56 rounded-2xl shadow"
                />
              )}
              {att.type === "audio" &&
                (att.url ? (
                  <audio
                    controls
                    src={att.url}
                    className="h-10 w-60 max-w-full"
                  />
                ) : (
                  <Expired label="Voice note" />
                ))}
              {att.type === "file" &&
                (att.url ? (
                  <a
                    href={att.url}
                    download={att.name}
                    className="flex items-center gap-2.5 rounded-2xl bg-black/30 px-3.5 py-3 hover:bg-black/45"
                  >
                    <span className="text-2xl">
                      {att.mime.includes("pdf") ? "📕" : "📄"}
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-bold">
                        {att.name}
                      </span>
                      <span className="text-[10px] opacity-75">
                        {att.size ? (att.size / 1024).toFixed(0) + " KB · " : ""}
                        tap to download
                      </span>
                    </span>
                  </a>
                ) : (
                  <Expired label={att.name} />
                ))}
            </div>
          )}
          <p
            className={`mt-1 text-right text-[10px] ${
              mine ? "text-white/70" : "text-slate-400"
            }`}
          >
            {fmtTime(m.ts)}
          </p>
        </div>
        <Reactions m={m} onReact={onReact} />

        {/* Hover Action Buttons */}
        <div
          className={`absolute -top-2 ${
            mine ? "-left-2" : "-right-2"
          } hidden gap-1 group-hover:flex`}
        >
          <button
            onClick={togglePicker}
            className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-700 text-[10px] shadow hover:bg-slate-600"
          >
            😊
          </button>
          <button
            onClick={onDelete}
            className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-700 text-[10px] shadow hover:bg-slate-600"
          >
            {mine ? "🗑" : "🚩"}
          </button>
        </div>

        {pickerOpen && (
          <div
            className={`absolute -top-11 z-30 flex gap-1 rounded-2xl border border-white/10 bg-slate-800 p-1.5 shadow-2xl ${
              mine ? "right-0" : "left-0"
            }`}
          >
            {REACTIONS.map((e) => (
              <button
                key={e}
                onClick={() => onReact(e)}
                className="rounded-lg px-2 py-0.5 text-lg hover:scale-125 hover:bg-slate-700"
              >
                {e}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Expired({ label }: { label: string }) {
  return (
    <p className="rounded-xl bg-black/30 px-3 py-2 text-xs italic opacity-70">
      📦 {label} — available during live room session only
    </p>
  );
}