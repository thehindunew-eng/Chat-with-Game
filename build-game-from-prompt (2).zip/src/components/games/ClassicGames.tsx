import { useState } from "react";
import type { GameProps } from "./CoopGames";
import { bumpScore, currentPlayer, feed, isMyTurn } from "../../lib/gameSync";
import { c4DropRow, c4Winner, slideNeighbors, slideSolved, tttWinner, type Mark } from "../../lib/classic";
import { sounds } from "../../lib/audio";

function TurnBar({ g, me, label }: GameProps & { label?: string }) {
  const player = currentPlayer(g);
  const mine = player?.uid === me.id;
  return (
    <div className={`mb-3 flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-bold ${mine ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-200" : "border-white/10 bg-slate-800/70 text-slate-300"}`}>
      {player && <img src={player.avatar} alt="" className="h-6 w-6 rounded-full object-cover" />}
      <span>{mine ? "Your move" : `${player?.name}'s move`}{label ? ` · ${label}` : ""}</span>
      <span className="ml-auto rounded-lg bg-black/25 px-2 py-0.5 font-mono text-[10px]">{g.turn % 2 === 0 ? "X / RED" : "O / YELLOW"}</span>
    </div>
  );
}

export function TicTacToeGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as { board: Mark[]; moves: number; winner: number[] | null };
  const mine = isMyTurn(g, me.id);
  const mark = (g.turn % 2) as 0 | 1;

  const play = (index: number) => {
    if (!mine || d.board[index] !== null || d.winner) return;
    const board = [...d.board];
    board[index] = mark;
    const won = tttWinner(board);
    const moves = d.moves + 1;
    sounds.playPop();
    mutate((cur) => bumpScore({
      ...cur,
      turn: (cur.turn + 1) % cur.players.length,
      data: { ...cur.data, board, moves, winner: won?.line || null },
    }, me.id, won ? 5 : 1));
    if (won) {
      sounds.playSuccess();
      finish(`${me.name} landed the winning ${mark === 0 ? "X" : "O"} — ${mark === 0 ? "Team X" : "Team O"} wins Tic-Tac-Toe ⭕`);
    } else if (moves === 9) {
      finish("the shared Tic-Tac-Toe board ended in a perfectly played draw 🤝");
    }
  };

  return (
    <div>
      <TurnBar g={g} me={me} mutate={mutate} finish={finish} label={mark === 0 ? "Team X" : "Team O"} />
      <div className="mx-auto grid w-full max-w-[300px] grid-cols-3 gap-2.5">
        {d.board.map((cell, i) => (
          <button key={i} onClick={() => play(i)} disabled={!mine || cell !== null}
            className={`flex aspect-square items-center justify-center rounded-2xl border text-5xl font-black transition active:scale-95 ${d.winner?.includes(i) ? "border-emerald-400 bg-emerald-500/25" : "border-white/10 bg-slate-800/80 hover:border-violet-400 hover:bg-slate-700"} ${cell === 0 ? "text-cyan-300" : "text-rose-300"}`}>
            {cell === 0 ? "×" : cell === 1 ? "○" : ""}
          </button>
        ))}
      </div>
      <p className="mt-3 text-center text-xs text-slate-400">{d.moves}/9 squares filled · On a shared screen, simply pass the device when the turn changes.</p>
    </div>
  );
}

export function Connect4Game({ g, me, mutate, finish }: GameProps) {
  const d = g.data as { board: Mark[][]; moves: number; winner: [number, number][] | null };
  const mine = isMyTurn(g, me.id);
  const mark = (g.turn % 2) as 0 | 1;
  const [hoverCol, setHoverCol] = useState<number | null>(null);

  const play = (col: number) => {
    if (!mine || d.winner) return;
    const row = c4DropRow(d.board, col);
    if (row < 0) return;
    const board = d.board.map((r) => [...r]);
    board[row][col] = mark;
    const won = c4Winner(board, row, col, mark);
    const moves = d.moves + 1;
    sounds.playPop();
    mutate((cur) => bumpScore({
      ...cur,
      turn: (cur.turn + 1) % cur.players.length,
      data: { ...cur.data, board, moves, winner: won || null },
    }, me.id, won ? 6 : 1));
    if (won) {
      sounds.playSuccess();
      finish(`${me.name} connected four ${mark === 0 ? "red" : "yellow"} discs — ${mark === 0 ? "Red" : "Yellow"} team wins 🔴`);
    } else if (moves === 42) {
      finish("Connect Four filled the whole board — squad draw 🤝");
    }
  };

  return (
    <div>
      <TurnBar g={g} me={me} mutate={mutate} finish={finish} label={mark === 0 ? "Red team" : "Yellow team"} />
      <div className="mx-auto max-w-[440px] rounded-2xl border-2 border-blue-500/50 bg-blue-950/70 p-2 shadow-xl">
        <div className="mb-1.5 grid grid-cols-7 gap-1.5">
          {Array.from({ length: 7 }, (_, col) => (
            <button key={col} onClick={() => play(col)} disabled={!mine || c4DropRow(d.board, col) < 0}
              onMouseEnter={() => setHoverCol(col)} onMouseLeave={() => setHoverCol(null)}
              className="rounded-lg py-1 text-xs font-black text-blue-200 transition hover:bg-blue-500/30 disabled:opacity-30">▼</button>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {d.board.flatMap((row, r) => row.map((cell, c) => {
            const winning = d.winner?.some(([wr, wc]) => wr === r && wc === c);
            return (
              <button key={`${r}-${c}`} onClick={() => play(c)} disabled={!mine}
                onMouseEnter={() => setHoverCol(c)} onMouseLeave={() => setHoverCol(null)}
                className={`flex aspect-square items-center justify-center rounded-full border transition ${winning ? "ring-4 ring-emerald-300" : ""} ${hoverCol === c && mine ? "bg-blue-800" : "bg-slate-950/80"} ${cell === 0 ? "border-rose-300 bg-rose-500" : cell === 1 ? "border-amber-200 bg-amber-400" : "border-blue-800/60"}`} />
            );
          }))}
        </div>
      </div>
      <p className="mt-2 text-center text-xs text-slate-400">{d.moves}/42 discs · Connect four horizontally, vertically or diagonally.</p>
    </div>
  );
}

export function SlidingPuzzleGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as { board: number[]; size: number; moves: number };
  const mine = isMyTurn(g, me.id);
  const blank = d.board.indexOf(0);
  const movable = slideNeighbors(blank, d.size);
  const player = currentPlayer(g);

  const move = (index: number) => {
    if (!mine || !movable.includes(index)) return;
    const board = [...d.board];
    [board[blank], board[index]] = [board[index], board[blank]];
    const moves = d.moves + 1;
    sounds.playTick();
    mutate((cur) => feed(bumpScore({
      ...cur,
      turn: (cur.turn + 1) % cur.players.length,
      data: { ...cur.data, board, moves },
    }, me.id, 1), { name: me.name, text: `slid tile ${d.board[index]} · move ${moves}`, ts: Date.now(), sys: true }));
    if (slideSolved(board)) {
      sounds.playSuccess();
      finish(`the squad restored the sliding grid in ${moves} coordinated moves 🧩 (${me.name} placed the final tile)`);
    }
  };

  return (
    <div>
      <div className={`mb-3 flex items-center gap-2 rounded-2xl border px-3 py-2 text-xs font-bold ${mine ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-200" : "border-white/10 bg-slate-800/70"}`}>
        {player && <img src={player.avatar} alt="" className="h-6 w-6 rounded-full object-cover" />}
        {mine ? "Your turn — slide one tile into the empty space" : `${player?.name} is choosing a tile`}
        <span className="ml-auto font-mono">{d.moves} moves</span>
      </div>
      <div className="mx-auto grid w-full max-w-[330px] grid-cols-3 gap-2 rounded-2xl bg-slate-950/70 p-2.5">
        {d.board.map((tile, i) => (
          <button key={i} onClick={() => move(i)} disabled={!mine || !movable.includes(i) || tile === 0}
            className={`flex aspect-square items-center justify-center rounded-2xl border text-3xl font-black transition active:scale-95 ${tile === 0 ? "border-dashed border-white/10 bg-slate-950 text-transparent" : movable.includes(i) && mine ? "border-violet-400 bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white shadow-lg hover:brightness-125" : "border-white/10 bg-slate-800 text-slate-400"}`}>
            {tile || "·"}
          </button>
        ))}
      </div>
      <div className="mt-3 grid grid-cols-9 gap-1 rounded-xl bg-black/25 p-2 text-center text-[10px] text-slate-400">
        {Array.from({ length: 9 }, (_, i) => <span key={i} className={i === 8 ? "opacity-30" : ""}>{i === 8 ? "·" : i + 1}</span>)}
      </div>
      <p className="mt-2 text-center text-xs text-slate-400">Target layout shown above · The puzzle was shuffled only with legal moves, so it is always solvable.</p>
    </div>
  );
}