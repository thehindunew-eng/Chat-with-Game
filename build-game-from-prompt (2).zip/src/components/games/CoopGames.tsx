import { useEffect, useMemo, useRef, useState } from "react";
import type { LiveGame, User } from "../../lib/types";
import {
  CODE_SYMBOLS,
  bumpScore,
  currentPlayer,
  feed,
  isMyTurn,
  mulberry32,
  scoreGuess,
} from "../../lib/gameSync";
import { sounds } from "../../lib/audio";

export interface GameProps {
  g: LiveGame;
  me: User;
  mutate: (fn: (g: LiveGame) => LiveGame | null) => void;
  finish: (result: string, bonus?: string) => void;
}

const nextTurn = (g: LiveGame): LiveGame => ({
  ...g,
  turn: (g.turn + 1) % Math.max(1, g.players.length),
});

function TurnBanner({ g, me }: { g: LiveGame; me: User }) {
  const cur = currentPlayer(g);
  const mine = cur?.uid === me.id;
  return (
    <div
      className={`mb-3 flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-bold transition ${
        mine
          ? "border border-emerald-400/40 bg-emerald-500/20 text-emerald-100 shadow-md shadow-emerald-950/40"
          : "border border-white/5 bg-slate-800/80 text-slate-300"
      }`}
    >
      {cur && (
        <img
          src={cur.avatar}
          alt=""
          className="h-6 w-6 rounded-full border border-white/20 object-cover"
        />
      )}
      {mine ? "🫵 Your turn — squad is counting on you!" : `⏳ ${cur?.name ?? "…"} is taking this turn`}
      <span className="ml-auto text-xs font-semibold text-slate-400">
        {g.players.length} in squad
      </span>
    </div>
  );
}

/* ================= 1. Defuse the Bomb ================= */
export function BombGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as {
    wires: { color: string; hex: string; emoji: string }[];
    correct: number;
    clues: string[];
    cut: number[];
    strikes: number;
  };
  const myIdx = Math.max(0, g.players.findIndex((p) => p.uid === me.id));
  const solo = g.players.filter((p) => !p.bot).length <= 1;
  const myClues = solo ? d.clues : d.clues.filter((_, i) => i % g.players.length === myIdx);

  const cut = (i: number) => {
    if (d.cut.includes(i) || g.phase === "done") return;
    if (i === d.correct) {
      sounds.playSuccess();
      mutate((cur) =>
        feed(
          bumpScore(
            { ...cur, data: { ...cur.data, cut: [...cur.data.cut, i] } },
            me.id,
            4
          ),
          {
            name: "",
            text: `✅ ${me.name} snipped the ${d.wires[i].color} wire — BOMB DEFUSED!`,
            ts: Date.now(),
            sys: true,
          }
        )
      );
      finish(`the team defused the bomb 🧨 (${me.name} snipped the safe ${d.wires[i].color} wire)`);
    } else {
      sounds.playError();
      const strikes = d.strikes + 1;
      mutate((cur) =>
        feed(
          { ...cur, data: { ...cur.data, cut: [...cur.data.cut, i], strikes } },
          {
            name: "",
            text: `💥 ${me.name} cut ${d.wires[i].color} — WRONG! Strike ${strikes}/3`,
            ts: Date.now(),
            sys: true,
          }
        )
      );
      if (strikes >= 3) {
        finish(
          `the bomb detonated after 3 wrong cuts 💥 (safe wire was #${d.correct + 1}, ${d.wires[d.correct].color})`
        );
      }
    }
  };

  return (
    <div>
      <div className="mb-3 rounded-2xl border border-amber-500/40 bg-gradient-to-br from-amber-500/15 to-amber-950/20 p-3.5">
        <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-amber-300">
          <span>🤫</span>
          <span>
            Your confidential clue{" "}
            {solo ? "(Solo mode — you see all clues)" : `(Clue piece ${myIdx + 1} of ${g.players.length})`}
          </span>
        </p>
        <div className="space-y-1">
          {myClues.map((c, i) => (
            <p
              key={i}
              className="text-sm leading-relaxed text-amber-100"
              dangerouslySetInnerHTML={{
                __html: "• " + c.replace(/\*\*(.+?)\*\*/g, "<b class='text-white font-bold'>$1</b>"),
              }}
            />
          ))}
        </div>
        {!solo && (
          <p className="mt-2 text-[11px] text-amber-400/90 font-medium">
            💬 Share your clue in the team channel below — combine notes with your squad before cutting!
          </p>
        )}
      </div>

      <div className="mb-2 flex items-center justify-between text-xs font-bold text-slate-300">
        <span>Cut the single safe wire</span>
        <span className="flex items-center gap-1">
          Strikes:{" "}
          <span className="text-sm">
            {"❌".repeat(d.strikes)}
            {"🖤".repeat(3 - d.strikes)}
          </span>
        </span>
      </div>

      <div className="grid grid-cols-5 gap-2.5">
        {d.wires.map((w, i) => {
          const isCut = d.cut.includes(i);
          return (
            <button
              key={i}
              onClick={() => cut(i)}
              disabled={isCut}
              className={`group flex flex-col items-center gap-1.5 rounded-2xl border p-3 transition active:scale-95 ${
                isCut
                  ? "border-slate-800 bg-slate-900/40 opacity-30 cursor-not-allowed"
                  : "border-white/10 bg-slate-800/90 hover:border-amber-400 hover:bg-slate-700/80 shadow-lg"
              }`}
            >
              <div
                className="h-12 w-2.5 rounded-full transition group-hover:scale-110"
                style={{ background: w.hex, opacity: isCut ? 0.2 : 1 }}
              />
              <span className="text-[11px] font-black uppercase text-slate-300">
                #{i + 1}
              </span>
              <span className="text-[10px] font-semibold text-slate-400 capitalize">
                {isCut ? "severed" : w.color}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ================= 2. Starship Repair ================= */
export function AstroGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as {
    modules: {
      id: number;
      name: string;
      icon: string;
      req: string;
      code: string;
      fixed: boolean;
      assignedTo: number;
    }[];
    integrity: number;
  };
  const [inputCode, setInputCode] = useState("");
  const myIdx = Math.max(0, g.players.findIndex((p) => p.uid === me.id));
  const myModules = d.modules.filter((_, i) => i % g.players.length === myIdx);

  const fixModule = (modId: number) => {
    const mod = d.modules.find((m) => m.id === modId);
    if (!mod || mod.fixed) return;
    if (inputCode.trim().toUpperCase() === mod.code) {
      sounds.playSuccess();
      setInputCode("");
      const updated = d.modules.map((m) => (m.id === modId ? { ...m, fixed: true } : m));
      const allDone = updated.every((m) => m.fixed);
      mutate((cur) =>
        feed(
          bumpScore(
            { ...cur, data: { ...cur.data, modules: updated } },
            me.id,
            2
          ),
          {
            name: me.name,
            text: `🔧 Repaired ${mod.name} with code [${mod.code}]!`,
            ts: Date.now(),
            sys: true,
          }
        )
      );
      if (allDone) {
        finish(`the squad repaired all starship systems and averted disaster 🚀`);
      }
    } else {
      sounds.playError();
      mutate((cur) =>
        feed(cur, {
          name: me.name,
          text: `⚠️ Wrong bypass code for ${mod.name}`,
          ts: Date.now(),
          sys: true,
        })
      );
    }
  };

  const fixedCount = d.modules.filter((m) => m.fixed).length;

  return (
    <div>
      <div className="mb-3 rounded-2xl border border-cyan-500/30 bg-cyan-950/20 p-3">
        <p className="text-[10px] font-black uppercase tracking-widest text-cyan-300">
          📡 Starship Status Console · Repairs: {fixedCount}/{d.modules.length}
        </p>
        <div className="mt-1 h-2 overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-emerald-400 transition-all duration-500"
            style={{ width: `${(fixedCount / d.modules.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="mb-3 space-y-2">
        {d.modules.map((m) => {
          const isMine = myModules.some((x) => x.id === m.id);
          return (
            <div
              key={m.id}
              className={`flex items-center gap-3 rounded-xl border p-2.5 transition ${
                m.fixed
                  ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-200"
                  : "border-white/10 bg-slate-800/80"
              }`}
            >
              <span className="text-2xl">{m.icon}</span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-bold text-sm text-white">{m.name}</p>
                  {m.fixed && (
                    <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[9px] font-bold text-emerald-300">
                      ONLINE ✓
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400">{m.req}</p>
                {isMine && !m.fixed && (
                  <p className="mt-0.5 font-mono text-[11px] font-bold text-amber-300">
                    🔑 Your manual override code: <b>{m.code}</b>
                  </p>
                )}
              </div>
              {!m.fixed && (
                <div className="flex gap-1.5">
                  <input
                    value={inputCode}
                    onChange={(e) => setInputCode(e.target.value.toUpperCase())}
                    placeholder="CODE"
                    className="w-20 rounded-lg border border-white/10 bg-slate-900 px-2 py-1 text-center font-mono text-xs uppercase text-white outline-none focus:border-cyan-400"
                  />
                  <button
                    onClick={() => fixModule(m.id)}
                    className="rounded-lg bg-cyan-600 px-2.5 py-1 text-xs font-bold text-white hover:bg-cyan-500"
                  >
                    Fix
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <p className="text-center text-[11px] text-slate-400">
        Share your codes in the team chat so whoever has the module can enter it!
      </p>
    </div>
  );
}

/* ================= 3. Quantum Reactor Sync ================= */
export function ReactorGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as {
    energy: number;
    targetEnergy: number;
    sequence: number[];
    step: number;
    overheat: number;
    frequencies: { name: string; color: string; hex: string; note: string }[];
  };

  const currentExpected = d.sequence[d.step % d.sequence.length];

  const tapFreq = (idx: number) => {
    if (g.phase === "done") return;
    if (idx === currentExpected) {
      sounds.playReactor();
      const newEnergy = d.energy + 2;
      const newStep = d.step + 1;
      mutate((cur) =>
        bumpScore(
          {
            ...cur,
            data: {
              ...cur.data,
              energy: newEnergy,
              step: newStep,
              overheat: Math.max(0, cur.data.overheat - 5),
            },
          },
          me.id,
          1
        )
      );
      if (newEnergy >= d.targetEnergy) {
        finish(`the squad synchronized the Quantum Reactor core to 100% capacity ⚡`);
      }
    } else {
      sounds.playError();
      const newHeat = d.overheat + 15;
      mutate((cur) =>
        feed(
          { ...cur, data: { ...cur.data, overheat: newHeat } },
          {
            name: me.name,
            text: `⚡ Frequency misalignment! Core heat at ${newHeat}%`,
            ts: Date.now(),
            sys: true,
          }
        )
      );
    }
  };

  const expectedFreq = d.frequencies[currentExpected];

  return (
    <div>
      <div className="mb-3 rounded-2xl border border-fuchsia-500/30 bg-fuchsia-950/20 p-3">
        <div className="flex items-center justify-between text-xs font-bold">
          <span className="text-fuchsia-300">⚡ Reactor Energy Output</span>
          <span className="text-white font-mono">
            {d.energy} / {d.targetEnergy} GW
          </span>
        </div>
        <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full rounded-full bg-gradient-to-r from-blue-500 via-fuchsia-500 to-amber-400 transition-all duration-300"
            style={{ width: `${Math.min(100, (d.energy / d.targetEnergy) * 100)}%` }}
          />
        </div>
      </div>

      <div className="mb-4 text-center">
        <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Target Harmonic Wave
        </p>
        <div
          className="mx-auto mt-1 inline-flex items-center gap-2 rounded-2xl px-5 py-2.5 font-mono text-base font-black text-white shadow-lg"
          style={{ background: expectedFreq.hex }}
        >
          <span>⚡</span>
          <span>{expectedFreq.name}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {d.frequencies.map((f, i) => (
          <button
            key={i}
            onClick={() => tapFreq(i)}
            className="group flex flex-col items-center gap-1 rounded-2xl border border-white/10 bg-slate-800/90 p-3.5 transition active:scale-95 hover:border-white/30 hover:bg-slate-700"
          >
            <div
              className="h-6 w-6 rounded-full shadow-md transition group-hover:scale-125"
              style={{ background: f.hex }}
            />
            <span className="text-xs font-bold text-white">{f.name.split(" ")[0]}</span>
            <span className="text-[10px] text-slate-400">{f.note}</span>
          </button>
        ))}
      </div>
      <p className="mt-3 text-center text-[11px] text-slate-400">
        All squad members tap the active frequency in sync to charge the grid!
      </p>
    </div>
  );
}

/* ================= 4. Emoji Cipher Hack ================= */
export function CipherGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as {
    phrase: string;
    words: string[];
    cipherMap: Record<string, string>;
    solvedWords: string[];
    guessWordIdx: number;
  };
  const [guess, setGuess] = useState("");
  const [err, setErr] = useState("");
  const targetWord = d.words[d.solvedWords.length] || "";

  const myIdx = Math.max(0, g.players.findIndex((p) => p.uid === me.id));
  const keys = Object.entries(d.cipherMap);
  const myKeys = keys.filter((_, idx) => idx % g.players.length === myIdx);

  const submit = () => {
    const val = guess.trim().toUpperCase();
    if (!val) return;
    if (val === targetWord) {
      sounds.playSuccess();
      setGuess("");
      setErr("");
      const solved = [...d.solvedWords, val];
      const allDone = solved.length >= d.words.length;
      mutate((cur) =>
        feed(
          bumpScore(
            { ...cur, data: { ...cur.data, solvedWords: solved } },
            me.id,
            3
          ),
          {
            name: me.name,
            text: `🔓 Decrypted word: "${val}"!`,
            ts: Date.now(),
            sys: true,
          }
        )
      );
      if (allDone) {
        finish(`the squad decrypted the entire coded transmission 🕵️`, `📜 **Decrypted message:** ${d.phrase}`);
      }
    } else {
      sounds.playError();
      setErr("Incorrect word — check the letter mappings!");
    }
  };

  return (
    <div>
      <div className="mb-3 rounded-2xl border border-violet-500/30 bg-violet-950/20 p-3">
        <p className="mb-1 text-[10px] font-black uppercase tracking-widest text-violet-300">
          🕵️ Your Secret Decryption Keyring (Fragment {myIdx + 1}/{g.players.length})
        </p>
        <div className="flex flex-wrap gap-2">
          {myKeys.map(([letter, rune]) => (
            <div
              key={letter}
              className="flex items-center gap-1 rounded-xl bg-slate-900/90 px-2.5 py-1 text-xs border border-violet-400/30 font-bold"
            >
              <span className="text-base">{rune}</span>
              <span className="text-slate-400">=</span>
              <span className="text-white text-sm">{letter}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mb-3 text-center">
        <p className="text-xs font-bold text-slate-400">
          Decrypt Word {d.solvedWords.length + 1} of {d.words.length}
        </p>
        <div className="mt-2 flex justify-center gap-2">
          {targetWord.split("").map((letter, i) => (
            <div
              key={i}
              className="flex h-12 w-10 flex-col items-center justify-center rounded-xl border border-white/10 bg-slate-800 text-lg font-black"
            >
              <span>{d.cipherMap[letter] || "❓"}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-2">
        <input
          value={guess}
          onChange={(e) => setGuess(e.target.value.toUpperCase())}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          maxLength={targetWord.length + 2}
          placeholder="TYPE DECRYPTED WORD"
          className="flex-1 rounded-xl border border-white/10 bg-slate-800 px-4 py-2.5 text-center font-bold tracking-widest text-white outline-none focus:border-violet-400"
        />
        <button
          onClick={submit}
          className="rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-5 font-bold text-white hover:brightness-110"
        >
          Unlock
        </button>
      </div>
      {err && <p className="mt-2 text-center text-xs text-rose-400 font-bold">{err}</p>}
    </div>
  );
}

/* ================= 5. Word Chain Relay ================= */
export function ChainGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as {
    words: { word: string; by: string }[];
    target: number;
    startLetter: string;
  };
  const [val, setVal] = useState("");
  const [err, setErr] = useState("");
  const last = d.words[d.words.length - 1];
  const need = (last ? last.word[last.word.length - 1] : d.startLetter).toUpperCase();
  const mine = isMyTurn(g, me.id);

  const submit = () => {
    const w = val.trim().toLowerCase();
    if (!/^[a-z]{3,}$/.test(w)) return setErr("Letters only, at least 3 letters.");
    if (w[0].toUpperCase() !== need) return setErr(`Must begin with letter "${need}".`);
    if (d.words.some((x) => x.word === w)) return setErr("That word is already used!");
    sounds.playPop();
    setErr("");
    setVal("");
    const words = [...d.words, { word: w, by: me.name }];
    mutate((cur) =>
      nextTurn(
        feed(
          bumpScore({ ...cur, data: { ...cur.data, words } }, me.id, 1),
          { name: me.name, text: `added "${w}"`, ts: Date.now(), sys: true }
        )
      )
    );
    if (words.length >= d.target) {
      finish(
        `the squad built an unbroken ${words.length}-word chain relay 🔗`,
        `🔗 **Team chain:** ${words.map((x) => x.word).join(" → ")}`
      );
    }
  };

  return (
    <div>
      <TurnBanner g={g} me={me} />
      <div className="mb-3 flex items-center justify-between text-xs font-bold text-slate-400">
        <span>Chain Length</span>
        <span className="text-violet-300 font-mono">
          {d.words.length} / {d.target} words
        </span>
      </div>
      <div className="mb-3 h-2 overflow-hidden rounded-full bg-slate-800">
        <div
          className="h-full rounded-full bg-gradient-to-r from-violet-500 to-emerald-400 transition-all"
          style={{ width: `${(d.words.length / d.target) * 100}%` }}
        />
      </div>
      <div className="mb-3 flex max-h-24 flex-wrap gap-1.5 overflow-y-auto rounded-xl bg-slate-950/60 p-2.5">
        {d.words.length === 0 && (
          <p className="p-1 text-xs text-slate-500">
            Chain begins! First word must start with "{need}".
          </p>
        )}
        {d.words.map((w, i) => (
          <span
            key={i}
            className="rounded-lg bg-slate-800 px-2.5 py-1 text-xs font-bold text-violet-200 shadow"
            title={"by " + w.by}
          >
            {w.word}
            <span className="ml-1 text-[9px] font-normal text-slate-400">
              ({w.by.split(" ")[0]})
            </span>
          </span>
        ))}
      </div>
      <div className="flex gap-2">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-violet-600 text-xl font-black text-white">
          {need}
        </div>
        <input
          value={val}
          disabled={!mine}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder={mine ? `Word starting with ${need}…` : "Waiting for squad teammate…"}
          className="flex-1 rounded-xl border border-white/10 bg-slate-800 px-3.5 text-white placeholder-slate-500 outline-none focus:border-violet-400 disabled:opacity-40"
        />
        <button
          onClick={submit}
          disabled={!mine}
          className="rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-5 font-bold text-white disabled:opacity-40"
        >
          Add
        </button>
      </div>
      {mine && (
        <button
          onClick={() => {
            sounds.playPop();
            mutate((cur) =>
              nextTurn(
                feed(cur, {
                  name: me.name,
                  text: "passed the turn 🤷",
                  ts: Date.now(),
                  sys: true,
                })
              )
            );
          }}
          className="mt-2 w-full rounded-xl bg-slate-800 py-2 text-xs font-semibold text-slate-400 hover:bg-slate-700"
        >
          Pass to next teammate →
        </button>
      )}
      {err && <p className="mt-2 text-center text-xs font-semibold text-rose-300">{err}</p>}
    </div>
  );
}

/* ================= 6. Target Blitz Co-op ================= */
export function BlitzGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as {
    total: number;
    target: number;
    hits: Record<string, number>;
  };
  const rnd = useMemo(() => {
    const r = mulberry32(g.seed + d.total * 977);
    return { x: 12 + r() * 76, y: 15 + r() * 70 };
  }, [g.seed, d.total]);
  const [pops, setPops] = useState<{ id: number; x: number; y: number }[]>([]);

  const hit = () => {
    if (g.phase === "done") return;
    sounds.playPop();
    setPops((p) => [...p.slice(-4), { id: Date.now(), x: rnd.x, y: rnd.y }]);
    const total = d.total + 1;
    mutate((cur) =>
      bumpScore(
        {
          ...cur,
          data: {
            ...cur.data,
            total,
            hits: { ...cur.data.hits, [me.id]: (cur.data.hits[me.id] || 0) + 1 },
          },
        },
        me.id,
        1
      )
    );
    if (total >= d.target) {
      finish(`the squad crushed all ${d.target} targets together 🎯`);
    }
  };

  const size = Math.max(38, 64 - Math.floor(d.total / 2) * 2);
  const top = [...g.players].sort((a, b) => (d.hits[b.uid] || 0) - (d.hits[a.uid] || 0));

  return (
    <div>
      <div className="mb-2 flex items-center justify-between text-xs font-bold">
        <span className="text-slate-400">Shared Squad Goal</span>
        <span className="font-mono text-amber-300">
          🎯 {d.total} / {d.target}
        </span>
      </div>
      <div className="mb-2 h-2.5 overflow-hidden rounded-full bg-slate-800">
        <div
          className="h-full rounded-full bg-gradient-to-r from-amber-400 to-rose-500 transition-all duration-150"
          style={{ width: `${Math.min(100, (d.total / d.target) * 100)}%` }}
        />
      </div>
      <div className="relative mb-3 h-56 overflow-hidden rounded-2xl border border-white/10 bg-slate-950/80 sm:h-64">
        <button
          onClick={hit}
          style={{ left: `${rnd.x}%`, top: `${rnd.y}%`, width: size, height: size }}
          className="absolute -translate-x-1/2 -translate-y-1/2 transition-transform active:scale-75 cursor-pointer"
        >
          <span
            className="flex h-full w-full items-center justify-center rounded-full bg-gradient-to-br from-rose-500 to-amber-400 shadow-xl shadow-rose-900/60"
            style={{ fontSize: size * 0.52 }}
          >
            🎯
          </span>
        </button>
        {pops.map((p) => (
          <span
            key={p.id}
            style={{ left: `${p.x}%`, top: `${p.y}%` }}
            className="pop-fade pointer-events-none absolute text-xl font-black text-amber-300"
          >
            +1
          </span>
        ))}
        <p className="pointer-events-none absolute inset-x-0 bottom-2 text-center text-[11px] text-slate-500">
          Shared live target — every hit syncs across all online screens!
        </p>
      </div>
      <div className="space-y-1.5">
        {top.map((p) => (
          <div key={p.uid} className="flex items-center gap-2">
            <img src={p.avatar} alt="" className="h-5 w-5 rounded-full object-cover" />
            <span className="w-20 shrink-0 truncate text-xs font-semibold">{p.name}</span>
            <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full rounded-full bg-violet-500 transition-all"
                style={{ width: `${Math.min(100, ((d.hits[p.uid] || 0) / d.target) * 100)}%` }}
              />
            </div>
            <span className="w-6 text-right text-xs font-bold text-slate-400">
              {d.hits[p.uid] || 0}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================= 7. Code Breakers ================= */
export function CodeGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as {
    code: number[];
    guesses: { by: string; guess: number[]; exact: number; partial: number }[];
    maxGuesses: number;
  };
  const [draft, setDraft] = useState<number[]>([0, 1, 2, 3]);
  const mine = isMyTurn(g, me.id);
  const logRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    logRef.current?.scrollTo({ top: 9999 });
  }, [d.guesses.length]);

  const cycle = (slot: number, dir: number) => {
    sounds.playPop();
    setDraft((p) =>
      p.map((v, i) => (i === slot ? (v + dir + CODE_SYMBOLS.length) % CODE_SYMBOLS.length : v))
    );
  };

  const submit = () => {
    const s = scoreGuess(d.code, draft);
    sounds.playTick();
    const guesses = [
      ...d.guesses,
      { by: me.name, guess: [...draft], exact: s.exact, partial: s.partial },
    ];
    mutate((cur) =>
      nextTurn(
        feed(
          bumpScore({ ...cur, data: { ...cur.data, guesses } }, me.id, s.exact),
          {
            name: me.name,
            text: `guessed ${draft.map((i) => CODE_SYMBOLS[i]).join("")} → ${s.exact}🎯 ${s.partial}🔆`,
            ts: Date.now(),
            sys: true,
          }
        )
      )
    );
    if (s.exact === 4) {
      finish(
        `the squad cracked the secret code 🧩 in ${guesses.length} attempts (${me.name} landed it!)`
      );
    } else if (guesses.length >= d.maxGuesses) {
      finish(
        `the team used all guesses 🧩 — secret code was ${d.code.map((i) => CODE_SYMBOLS[i]).join("")}`
      );
    }
  };

  return (
    <div>
      <TurnBanner g={g} me={me} />
      <div
        ref={logRef}
        className="mb-3 max-h-36 space-y-1.5 overflow-y-auto rounded-xl bg-slate-950/60 p-2.5"
      >
        {d.guesses.length === 0 && (
          <p className="p-2 text-center text-xs text-slate-500">
            No deductions yet. 🎯 = right symbol in slot · 🔆 = right symbol in wrong slot.
          </p>
        )}
        {d.guesses.map((gu, i) => (
          <div
            key={i}
            className="flex items-center gap-2 rounded-lg bg-slate-800/80 px-2.5 py-1.5"
          >
            <span className="w-5 text-[10px] font-bold text-slate-500">#{i + 1}</span>
            <span className="text-lg tracking-wider">
              {gu.guess.map((s) => CODE_SYMBOLS[s]).join("")}
            </span>
            <span className="ml-auto text-xs font-bold text-emerald-300">
              {gu.exact} 🎯
            </span>
            <span className="text-xs font-bold text-amber-300">
              {gu.partial} 🔆
            </span>
            <span className="w-16 truncate text-right text-[10px] text-slate-400">
              {gu.by}
            </span>
          </div>
        ))}
      </div>
      <div className="mb-3 flex items-center justify-center gap-2">
        {draft.map((v, i) => (
          <div key={i} className="flex flex-col items-center gap-1">
            <button
              onClick={() => cycle(i, 1)}
              disabled={!mine}
              className="text-xs text-slate-500 hover:text-white disabled:opacity-30"
            >
              ▲
            </button>
            <button
              onClick={() => cycle(i, 1)}
              disabled={!mine}
              className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-slate-800 text-2xl shadow disabled:opacity-40"
            >
              {CODE_SYMBOLS[v]}
            </button>
            <button
              onClick={() => cycle(i, -1)}
              disabled={!mine}
              className="text-xs text-slate-500 hover:text-white disabled:opacity-30"
            >
              ▼
            </button>
          </div>
        ))}
      </div>
      <button
        onClick={submit}
        disabled={!mine}
        className="w-full rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 py-2.5 font-bold text-white shadow-lg disabled:opacity-40"
      >
        Submit Squad Guess ({d.guesses.length}/{d.maxGuesses})
      </button>
    </div>
  );
}

/* ================= 8. Story Relay ================= */
export function StoryGame({ g, me, mutate, finish }: GameProps) {
  const d = g.data as {
    prompt: string;
    parts: { by: string; text: string }[];
    target: number;
  };
  const [val, setVal] = useState("");
  const mine = isMyTurn(g, me.id);

  const submit = () => {
    const t = val.trim().replace(/\s+/g, " ");
    if (t.split(" ").length < 2) return;
    sounds.playSend();
    setVal("");
    const parts = [
      ...d.parts,
      { by: me.name, text: t.split(" ").slice(0, 9).join(" ") },
    ];
    mutate((cur) =>
      nextTurn(bumpScore({ ...cur, data: { ...cur.data, parts } }, me.id, 1))
    );
    if (parts.length >= d.target) {
      const story = d.prompt + " " + parts.map((p) => p.text).join(" ");
      finish(
        `the squad wrote a ${parts.length}-chapter story together 📖`,
        `📖 The team's story: ${story}`
      );
    }
  };

  return (
    <div>
      <TurnBanner g={g} me={me} />
      <div className="mb-3 max-h-36 overflow-y-auto rounded-2xl border border-white/10 bg-slate-950/60 p-3.5 text-sm leading-relaxed">
        <span className="font-bold italic text-fuchsia-300">{d.prompt}</span>{" "}
        {d.parts.map((p, i) => (
          <span key={i} className="text-slate-200" title={"by " + p.by}>
            {p.text}{" "}
          </span>
        ))}
        {d.parts.length === 0 && (
          <span className="text-slate-500">…continue the tale!</span>
        )}
      </div>
      <div className="mb-2 flex items-center justify-between text-xs font-bold text-slate-400">
        <span>Story Progress</span>
        <span className="text-fuchsia-300 font-mono">
          {d.parts.length} / {d.target} parts
        </span>
      </div>
      <div className="flex gap-2">
        <input
          value={val}
          disabled={!mine}
          maxLength={80}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder={mine ? "Add 2–8 words to the story…" : "Waiting for squad teammate…"}
          className="flex-1 rounded-xl border border-white/10 bg-slate-800 px-3.5 py-2.5 text-white placeholder-slate-500 outline-none focus:border-fuchsia-400 disabled:opacity-40"
        />
        <button
          onClick={submit}
          disabled={!mine}
          className="rounded-xl bg-gradient-to-r from-fuchsia-600 to-rose-500 px-5 font-bold text-white disabled:opacity-40"
        >
          Add
        </button>
      </div>
    </div>
  );
}